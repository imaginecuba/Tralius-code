package com.zsoft.SignalA.Transport.longpolling;

import org.json.JSONObject;

public class JSONHelper {

    public static JSONObject ToJSONObject(String text) {
        JSONObject json;
        if (text == null) {
            return null;
        }
        try {
            json = new JSONObject(text);
        }
        catch (Exception e) {
            json = null;
        }
        return json;
    }
}
