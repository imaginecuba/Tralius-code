
package com.imagine.tralius.service.data.playlist;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class PlayListItem {


    @SerializedName("Items")
    private List<Item> items;
    @SerializedName("Order")
    private Long order;
    @SerializedName("Setting")
    private com.imagine.tralius.service.data.playlist.Setting setting;


    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }

    public com.imagine.tralius.service.data.playlist.Setting getSetting() {
        return setting;
    }

    public void setSetting(com.imagine.tralius.service.data.playlist.Setting setting) {
        this.setting = setting;
    }


    @Override
    public String toString() {
        return "PlayListItem{\n" +
                "\nitems=" + items +
                ", \norder=" + order +
                ", \nsetting=" + setting +
                "\n}";
    }
}
