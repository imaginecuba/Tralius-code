
package com.imagine.tralius.service.data.company;

import com.google.gson.annotations.SerializedName;
import com.imagine.tralius.service.data.Error;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class CompanyResult {

    @SerializedName("Error")
    private com.imagine.tralius.service.data.Error error;
    @SerializedName("Result")
    private com.imagine.tralius.service.data.company.Result result;
    @SerializedName("StatusCode")
    private Long statusCode;

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public Long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Long statusCode) {
        this.statusCode = statusCode;
    }

    @Override
    public String toString() {
        return "CompanyResult{" +
                "error=" + error +
                ", result=" + result +
                ", statusCode=" + statusCode +
                '}';
    }
}
