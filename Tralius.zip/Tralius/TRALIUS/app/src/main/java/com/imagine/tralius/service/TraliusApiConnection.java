package com.imagine.tralius.service;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.imagine.tralius.TraliusApp;
import com.imagine.tralius.service.data.company.CompanyResult;
import com.imagine.tralius.service.data.playlist.PlayListResult;
import com.imagine.tralius.service.data.serial.SerialResult;
import com.imagine.tralius.service.data.transition.TransitionResult;
import com.imagine.tralius.service.data.update.UpdateResult;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.ConnectionPool;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by Elvis on 2/8/2018.
 */

public class TraliusApiConnection {

    private final int cacheSize;
    private TraliusApiService service;
    private Retrofit retrofit;

    private final Interceptor REWRITE_RESPONSE_INTERCEPTOR = new Interceptor() {
        @Override
        public okhttp3.Response intercept(Chain chain) throws IOException {
            okhttp3.Response originalResponse = chain.proceed(chain.request());
            String cacheControl = originalResponse.header("Cache-Control");
            if (cacheControl == null || cacheControl.contains("no-store") || cacheControl.contains(
                    "no-cache") ||
                    cacheControl.contains("must-revalidate") || cacheControl.contains(
                    "max-age=0")) {
                return originalResponse.newBuilder()
                        .removeHeader("Pragma")
                        .header("Cache-Control", "public, max-age=" + cacheSize)
                        .build();
            }
            else {
                return originalResponse;
            }
        }
    };

    private final Interceptor REWRITE_RESPONSE_INTERCEPTOR_OFFLINE = new Interceptor() {
        @Override
        public okhttp3.Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            if (!isConnected()) {
                request = request.newBuilder()
                        .removeHeader("Pragma")
                        .header("Cache-Control", "public, only-if-cached")
                        .build();
            }
            return chain.proceed(request);
        }
    };

    public TraliusApiConnection() {

        cacheSize = 1024 * 1024 * 1024;
        Cache cache = new Cache(TraliusApp.getInstance().getApplicationContext().getCacheDir(),
                                cacheSize);
        ConnectionPool pool = new ConnectionPool(5, 10000, TimeUnit.MILLISECONDS);

        OkHttpClient client = new OkHttpClient
                .Builder()
                .connectionPool(pool)
                //.addNetworkInterceptor(REWRITE_RESPONSE_INTERCEPTOR)
                // .addInterceptor(REWRITE_RESPONSE_INTERCEPTOR_OFFLINE)
                //.cache(cache)
                .connectTimeout(15, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        retrofit = new Retrofit.Builder()
                .baseUrl(TraliusApiService.API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        service = retrofit.create(TraliusApiService.class);

    }

    public static boolean isConnected() {
        ConnectivityManager
                cm = (ConnectivityManager) TraliusApp.getInstance().getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null
                && activeNetwork.isConnectedOrConnecting();
    }


    //API METHODS
    public Call<SerialResult> GetNewSerial() {
        return service.getNewSerial();
    }

    public Call<TransitionResult> GetTransitionEfects() {
        return service.getTransitionEfects();
    }

    public Call<PlayListResult> GetData(String serial) {
        return service.getData(serial);
    }

    public Call<CompanyResult> GetSettings(String serial) {
        return service.getSettings(serial);
    }

    public Call<UpdateResult> GetUpdates(String serial) {
        return service.getUpdates(serial);
    }


}
