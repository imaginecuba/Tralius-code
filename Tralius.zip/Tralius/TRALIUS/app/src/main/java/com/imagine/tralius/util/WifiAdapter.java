package com.imagine.tralius.util;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.imagine.tralius.R;

import java.util.List;

public class WifiAdapter extends ArrayAdapter<ScanResult> {

    private Context context;
    private List<ScanResult> results;
    private TextView tv;
    private ImageView icon;

    public WifiAdapter(@NonNull Context context, int resource, @NonNull List<ScanResult> results) {
        super(context, resource, results);
        this.results = results;
        this.context = context;
    }

    @Override
    public int getCount() {
        return results.size();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_wifi, null,
                                                                     false);
        tv = view.findViewById(R.id.label_wifi);
        icon = view.findViewById(R.id.iv_icon);

        ScanResult result = results.get(position);
        tv.setText(result.SSID);

        String capabilities = result.capabilities;
        Log.wtf("ADAPTER capabilities", "" + capabilities);
        boolean isSecure = capabilities.contains("WPA") ||
                capabilities.contains("WPA2") || capabilities.contains("WEP");
        icon.setImageResource(isSecure ? R.drawable.ic_wifi_lock : R.drawable.ic_wifi_free);

        return view;
    }
}
