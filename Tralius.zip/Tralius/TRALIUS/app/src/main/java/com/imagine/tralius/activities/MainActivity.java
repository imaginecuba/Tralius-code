package com.imagine.tralius.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ToxicBakery.viewpager.transforms.AccordionTransformer;
import com.ToxicBakery.viewpager.transforms.BackgroundToForegroundTransformer;
import com.ToxicBakery.viewpager.transforms.CubeInTransformer;
import com.ToxicBakery.viewpager.transforms.CubeOutTransformer;
import com.ToxicBakery.viewpager.transforms.DefaultTransformer;
import com.ToxicBakery.viewpager.transforms.DepthPageTransformer;
import com.ToxicBakery.viewpager.transforms.FlipHorizontalTransformer;
import com.ToxicBakery.viewpager.transforms.FlipVerticalTransformer;
import com.ToxicBakery.viewpager.transforms.ForegroundToBackgroundTransformer;
import com.ToxicBakery.viewpager.transforms.RotateDownTransformer;
import com.ToxicBakery.viewpager.transforms.RotateUpTransformer;
import com.ToxicBakery.viewpager.transforms.ScaleInOutTransformer;
import com.ToxicBakery.viewpager.transforms.StackTransformer;
import com.ToxicBakery.viewpager.transforms.TabletTransformer;
import com.ToxicBakery.viewpager.transforms.ZoomInTransformer;
import com.ToxicBakery.viewpager.transforms.ZoomOutSlideTransformer;
import com.ToxicBakery.viewpager.transforms.ZoomOutTranformer;
import com.bumptech.glide.Glide;
import com.iamhabib.easy_preference.EasyPreference;
import com.imagine.tralius.R;
import com.imagine.tralius.custom.TraliusCarouselView;
import com.imagine.tralius.kiosko.KioskoModeActivity;
import com.imagine.tralius.kiosko.PrefUtils;
import com.imagine.tralius.service.TraliusApiConnection;
import com.imagine.tralius.service.TraliusApiService;
import com.imagine.tralius.service.data.company.CompanyResult;
import com.imagine.tralius.service.data.playlist.Item;
import com.imagine.tralius.service.data.playlist.PlayListItem;
import com.imagine.tralius.service.data.playlist.PlayListResult;
import com.imagine.tralius.service.data.playlist.Result;
import com.imagine.tralius.service.data.playlist.Setting;
import com.imagine.tralius.service.data.serial.SerialResult;
import com.imagine.tralius.service.data.update.UpdateResult;
import com.imagine.tralius.util.Util;
import com.imagine.tralius.util.WifiAdapter;
import com.mklimek.frameviedoview.FrameVideoView;
import com.mklimek.frameviedoview.FrameVideoViewListener;
import com.rw.velocity.Velocity;
import com.synnapps.carouselview.ViewListener;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.yarolegovich.lovelydialog.LovelyChoiceDialog;
import com.yarolegovich.lovelydialog.LovelyInfoDialog;
import com.yarolegovich.lovelydialog.LovelyTextInputDialog;
import com.yarolegovich.lovelydialog.ViewConfigurator;
import com.zsoft.SignalA.Hubs.HubConnection;
import com.zsoft.SignalA.Hubs.HubInvokeCallback;
import com.zsoft.SignalA.Hubs.HubOnDataCallback;
import com.zsoft.SignalA.Hubs.IHubProxy;
import com.zsoft.SignalA.Transport.StateBase;
import com.zsoft.SignalA.Transport.longpolling.LongPollingTransport;

import org.json.JSONArray;
import org.polaric.colorful.Colorful;
import org.polaric.colorful.ThemeDelegate;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends KioskoModeActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private static final int ACCESS_FILE_REQUEST_CODE = 2367;
    private static final int INSTALL_REQUEST_CODE = 4839;
    private TextView show_hour;
    private FloatingActionButton fab;
    private TraliusApiConnection apiConnection;
    private File traliusFolder, downFolder, logoFolder;

    private int DOWNLOADS_COUNT = 0;
    private List<File> fileList;
    private List<FrameVideoView> frameVideoViewList;
    private TraliusCarouselView customCarouselView;
    private String SERIAL = "";
    private NavigationView navigationView;
    private ImageView img_logo, iv_calendar;
    private TextView text_company_name;
    private HubConnection con;
    private IHubProxy hub;
    private EasyPreference.Builder preferences;
    private int[] sizes;
    private List<Integer> effectList;
    private List<Long> times;
    private List<String> listCaptions;
    private List<Long> listTimes;
    private List<String> captions;
    private List<Boolean> displayClocks;
    private List<Boolean> contentFits;
    private List<String> nameList, videoList;

    private TextView tvListCaption;

    WifiManager mainWifiObj;
    WifiScanReceiver wifiReciever = new WifiScanReceiver();
    private boolean status = false;

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (mainWifiObj != null)
                mainWifiObj.startScan();

            if (handler != null)
                handler.postDelayed(this, 2000);
        }
    };
    private Handler handler;
    private LovelyChoiceDialog dialog;

    private int colorError = android.R.color.holo_red_dark;
    private int colorInfo = Colorful.getThemeDelegate().getAccentColor().getColorRes();

    private String defaultSerial = "";
    private Colorful.ThemeColor primaryColor;
    private boolean first = true;
    private int currentPos;
    private Bundle savedInstanceState;
    private FrameVideoView frameVideoView;
    private List<MediaPlayer> players;
    private View notAssigned, notData, linear_content;
    private MenuItem contentUpdateMenuItem;
    private Dialog serialDialog;
    private Toolbar toolbar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.savedInstanceState = savedInstanceState;

        Colorful.applyTheme(MainActivity.this);

        primaryColor = Colorful.getThemeDelegate().getPrimaryColor();
        String name = primaryColor.name();
        Log.wtf("color", "onCreate() returned: " + name);

        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        notAssigned = findViewById(R.id.not_assigned);
        notData = findViewById(R.id.not_data);
        linear_content = findViewById(R.id.linear_content);
        preferences = EasyPreference.with(this, getString(R.string.app_name));

        String company_name = preferences.getString(getString(R.string.pref_company_name), "");
        iv_calendar = toolbar.findViewById(R.id.iv_calendar);
        iv_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SeeCalendar();
            }
        });
        TextView title_display = toolbar.findViewById(R.id.title_display);
        title_display.setText(
                company_name.isEmpty() ? getString(R.string.app_name) : company_name);
        toolbar.setBackgroundColor(
                ContextCompat.getColor(MainActivity.this, primaryColor.getColorRes()));
        setSupportActionBar(toolbar);
        hideActionBar();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            getWindow().setStatusBarColor(
                    ContextCompat.getColor(MainActivity.this, primaryColor.getDarkColorRes()));

        mainWifiObj = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        apiConnection = new TraliusApiConnection();
        show_hour = toolbar.findViewById(R.id.time_display);
        fab = findViewById(R.id.fab);
        tvListCaption = toolbar.findViewById(R.id.caption_display);
        final Handler showHourHandler = new Handler(getMainLooper());
        showHourHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long millis = System.currentTimeMillis();
                Calendar now = Calendar.getInstance();

                now.setTimeInMillis(millis);


                show_hour.setText(new SimpleDateFormat("hh:mm:ss").format(new Date()));
                showHourHandler.postDelayed(this, 1000);
            }
        }, 10);

        customCarouselView = findViewById(R.id.carouselView);
        customCarouselView.setIndicatorVisibility(View.INVISIBLE);
        customCarouselView.setAnimateOnBoundary(false);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        Menu drawerMenu = navigationView.getMenu();
        contentUpdateMenuItem = drawerMenu.findItem(R.id.nav_updates);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                &&
                (ContextCompat.checkSelfPermission(getApplicationContext(),
                                                   Manifest.permission.INTERNET)
                        != PackageManager.PERMISSION_GRANTED
                        ||
                        ContextCompat.checkSelfPermission(getApplicationContext(),
                                                          Manifest.permission
                                                                  .WRITE_EXTERNAL_STORAGE)
                                != PackageManager.PERMISSION_GRANTED))
            requestPermissions(new String[]{
                                       Manifest.permission.INTERNET,
                                       Manifest.permission.WRITE_EXTERNAL_STORAGE
                               },
                               ACCESS_FILE_REQUEST_CODE);
        else
            createFolder();

        ViewGroup headerView = (ViewGroup) navigationView.getHeaderView(0);
        headerView.setBackgroundColor(
                ContextCompat.getColor(MainActivity.this, primaryColor.getColorRes()));
        img_logo = headerView.findViewById(R.id.img_logo);
        text_company_name = headerView.findViewById(R.id.text_company_name);
        text_company_name.setText(company_name);

        String company_logo = preferences.getString(getString(R.string.pref_company_logo), "");
        boolean exists = new File(company_logo).exists();
        if (exists) {
            Bitmap bitmap = BitmapFactory.decodeFile(company_logo);
            img_logo.setImageBitmap(bitmap);
        }
        else
            img_logo.setImageResource(R.mipmap.ic_launcher_round);

        SERIAL = preferences.getString(getString(R.string.pref_serial), defaultSerial);
        if (!SERIAL.isEmpty()) {
            SignalR();
        }

        isLockedBackButton = PrefUtils.isKioskModeActive(this);

    }

    private String getFileType(File file) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(
                file.getAbsolutePath());
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    private String getFileType(String file) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(file);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }


    private void createFolder() {
        traliusFolder = new File(Environment.getExternalStorageDirectory(),
                                 getString(R.string.app_name));

        if (!traliusFolder.exists())
            traliusFolder.mkdir();

        downFolder = new File(traliusFolder, "down");
        if (!downFolder.exists())
            downFolder.mkdir();

        logoFolder = new File(traliusFolder, "logo");
        if (!logoFolder.exists())
            logoFolder.mkdir();


        boolean isAssigned = preferences.getBoolean(getString(R.string.pref_is_assigned), false);
        if (isAssigned) {
            notData.setVisibility(View.VISIBLE);
            notAssigned.setVisibility(View.GONE);
            linear_content.setVisibility(View.GONE);
        }

        boolean firstTime = preferences.getBoolean(getString(R.string.pref_is_first_time), true);
        if (!firstTime)
            ShowData();

        SERIAL = preferences.getString(getString(R.string.pref_serial), defaultSerial);
        if (SERIAL.isEmpty())
            GetNewSerial();

        boolean company = preferences.getBoolean(getString(R.string.pref_is_company), false);
        if (!SERIAL.isEmpty() && !company)
            GetCompany();

        if (!SERIAL.isEmpty() && company && firstTime)
            GetData();

        if (contentUpdateMenuItem != null) {
            contentUpdateMenuItem.setVisible(!SERIAL.isEmpty() && isAssigned);
        }


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onNavigationItemSelected(final MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_serial) {
            if (SERIAL.isEmpty()) {
                Snackbar.make(fab, R.string.no_serial, Snackbar.LENGTH_LONG)
                        .show();
            }
            else {
                serialDialog = new LovelyInfoDialog(MainActivity.this)
                        .setTopColorRes(colorInfo)
                        .setTopTitle(R.string.serial)
                        .setMessageGravity(Gravity.CENTER_HORIZONTAL)
                        .setMessage(FormatSerial(SERIAL))
                        .setConfirmButtonText(R.string.ok)
                        .setConfirmButtonColor(ContextCompat.getColor(
                                MainActivity.this,
                                colorInfo))
                        .configureView(new ViewConfigurator<View>() {
                            @Override
                            public void configureView(View v) {

                                int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                LinearLayout ld_color_area = v.findViewById(
                                        com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                ld_color_area.setPadding(0, padding, 0, padding);

                                TextView ld_message = v.findViewById(
                                        com.yarolegovich.lovelydialog.R.id.ld_message);
                                TextView ld_top_title = v.findViewById(
                                        com.yarolegovich.lovelydialog.R.id.ld_top_title);

                                ld_message.setTextAppearance(MainActivity.this,
                                                             android.R.style
                                                                     .TextAppearance_Material_Display1);
                                ld_message.setTypeface(Typeface.DEFAULT_BOLD);
                                ld_top_title.setTextAppearance(MainActivity.this,
                                                               android.R.style
                                                                       .TextAppearance_Material_Large);
                            }
                        })
                        .show();
            }
        }
        else if (id == R.id.nav_updates) {
            GetCompany();
            GetData();
        }
        else if (id == R.id.nav_wifi) {
            handler = new Handler();
            handler.post(runnable);

            WifiManager wifiManager = (WifiManager) getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            wifiManager.setWifiEnabled(!status);
            status = !status;
        }

        else if (id == R.id.nav_download) {
            Call<UpdateResult> call = apiConnection.GetUpdates(SERIAL);
            call.enqueue(new Callback<UpdateResult>() {
                @Override
                public void onResponse(Call<UpdateResult> call, Response<UpdateResult>
                        response) {

                    UpdateResult updateResult = response.body();
                    if (updateResult != null) {
                        Long code = updateResult.getStatusCode();
                        if (code == 200) {
                            com.imagine.tralius.service.data.update.Result result = updateResult
                                    .getResult();

                            if (result != null) {
                                com.imagine.tralius.service.data.update.Item item = result
                                        .getItem();
                                if (item != null)
                                    InstallNewVersion(item.getUrl());
                                else
                                    Snackbar.make(fab, R.string.no_updates,
                                                  Snackbar.LENGTH_LONG)
                                            .show();
                            }
                            else
                                Snackbar.make(fab, R.string.no_updates, Snackbar.LENGTH_LONG)
                                        .show();
                        }
                        else
                            Snackbar.make(fab, R.string.no_updates, Snackbar.LENGTH_LONG)
                                    .show();
                    }

                }

                @Override
                public void onFailure(Call<UpdateResult> call, Throwable throwable) {
                    new LovelyInfoDialog(MainActivity.this)
                            .setTopColorRes(colorError)
                            .setIcon(R.drawable.ic_error)
                            .setIconTintColor(Color.WHITE)
                            .setTitle(R.string.error)
                            .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                            .setMessage(R.string.error_no_connection)
                            .setConfirmButtonText(R.string.ok)
                            .configureView(new ViewConfigurator<View>() {
                                @Override
                                public void configureView(View v) {
                                    int padding = (int) getResources().getDimension(
                                            R.dimen._5sdp);
                                    LinearLayout ld_color_area = v.findViewById(
                                            com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                    ld_color_area.setPadding(0, padding, 0, padding);
                                }
                            })
                            .setConfirmButtonColor(ContextCompat.getColor(
                                    MainActivity.this,
                                    colorError))
                            .show();
                }
            });
        }

        else if (id == R.id.nav_kiosk) {
            isLockedBackButton = !isLockedBackButton;
            PrefUtils.setKioskModeActive(isLockedBackButton, this);
            Toast.makeText(this, "MODO KIOSKO " + (isLockedBackButton ? "" : "DES") + "ACTIVADO",
                           Toast.LENGTH_SHORT).show();
        }


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void ClearUpdates(final String fileName) {
        if (traliusFolder != null) {
            File[] files = traliusFolder.listFiles(new FilenameFilter() {
                @Override
                public boolean accept(File dir, String name) {
                    return name.endsWith(".apk") && !name.equals(fileName);
                }
            });
            for (File f : files) {
                f.delete();
            }
        }
    }

    private void SeeCalendar() {
        Calendar now = Calendar.getInstance();
        DatePickerDialog dpd = DatePickerDialog.newInstance(
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePickerDialog view, int year, int monthOfYear,
                                          int dayOfMonth) { }
                },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
                                                           );
        dpd.setAccentColor(ContextCompat.getColor(MainActivity.this, colorInfo));
        dpd.show(getFragmentManager(), "Datepickerdialog");

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == ACCESS_FILE_REQUEST_CODE
                &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
                &&
                grantResults[1] == PackageManager.PERMISSION_GRANTED)
            createFolder();
    }

    private void GetNewSerial() {
        Call<SerialResult> call = apiConnection.GetNewSerial();
        call.enqueue(new Callback<SerialResult>() {
            @Override
            public void onResponse(Call<SerialResult> call, Response<SerialResult> response) {
                SerialResult serialResult = response.body();

                if (response.code() == 200) {

                    com.imagine.tralius.service.data.serial.Result result = serialResult
                            .getResult();
                    Long statusCode = serialResult.getStatusCode();
                    if (statusCode == 200) {
                        preferences.addString(getString(R.string.pref_serial),
                                              result.getSerial());
                        preferences.save();
                    }
                    else {
                        SetNotAssigned();
                    }

                    SERIAL = preferences.getString(getString(R.string.pref_serial), defaultSerial);
                    Log.e("GetNewSerial", "onResponse: " + SERIAL);
                    if (!SERIAL.isEmpty()) {
                        SignalR();
                    }


                }
                else

                {
                    new LovelyInfoDialog(MainActivity.this)
                            .setTopColorRes(colorError)
                            .setIcon(R.drawable.ic_error)
                            .setIconTintColor(Color.WHITE)
                            .setTitle(R.string.error)
                            .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                            .setMessage(R.string.error_no_connection)
                            .setConfirmButtonText(R.string.ok)
                            .configureView(new ViewConfigurator<View>() {
                                @Override
                                public void configureView(View v) {
                                    int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                    LinearLayout ld_color_area = v.findViewById(
                                            com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                    ld_color_area.setPadding(0, padding, 0, padding);
                                }
                            })
                            .setConfirmButtonColor(ContextCompat.getColor(
                                    MainActivity.this,
                                    colorError))
                            .show();

                }
            }

            @Override
            public void onFailure(Call<SerialResult> call, Throwable t) {
                Log.e("GetNewSerial", "onFailure error: " + t.getLocalizedMessage());

                new LovelyInfoDialog(MainActivity.this)
                        .setTopColorRes(colorError)
                        .setIcon(R.drawable.ic_error)
                        .setIconTintColor(Color.WHITE)
                        .setTitle(R.string.error)
                        .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                        .setMessage(R.string.error_no_connection)
                        .setConfirmButtonText(R.string.ok)
                        .configureView(new ViewConfigurator<View>() {
                            @Override
                            public void configureView(View v) {
                                int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                LinearLayout ld_color_area = v.findViewById(
                                        com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                ld_color_area.setPadding(0, padding, 0, padding);
                            }
                        })
                        .setConfirmButtonColor(ContextCompat.getColor(
                                MainActivity.this,
                                colorError))
                        .show();
            }
        });
        Snackbar.make(fab, R.string.getting_serial, Snackbar.LENGTH_LONG)
                .show();
    }

    private void GetData() {

        SERIAL = preferences.getString(getString(R.string.pref_serial), defaultSerial);
        if (!SERIAL.isEmpty()) {
            Call<PlayListResult> call = apiConnection.GetData(SERIAL);
            call.enqueue(new Callback<PlayListResult>() {
                @Override
                public void onResponse(Call<PlayListResult> call, Response<PlayListResult>
                        response) {

                    Log.wtf("GetData", "onResponse() returned: " + call.request().url().toString());


                    PlayListResult playListResult = response.body();

                    if (response.code() == 200) {

                        Result result = playListResult.getResult();
                        preferences.addObject(getString(R.string.pref_result), result);
                        preferences.save();

                        if (result != null) {

                            preferences.addBoolean(getString(R.string.pref_is_assigned),
                                                   true);
                            preferences.save();

                            final List<PlayListItem> listItems = result.getPlayListItems();
                            int sum = 0;
                            List<String> names = new ArrayList<>();
                            for (PlayListItem pli : listItems) {
                                List<Item> list = pli.getItems();
                                if (list != null)
                                    for (Item i : list) {
                                        String fileName = Util.getFileName(i.getUrl());
                                        if (!names.contains(fileName)) {
                                            names.add(fileName);
                                            sum++;
                                        }
                                    }
                            }
                            if (listItems == null || listItems.isEmpty()) {
                                notData.setVisibility(View.VISIBLE);
                                notAssigned.setVisibility(View.GONE);
                                linear_content.setVisibility(View.GONE);

                            }
                            else {
                                notData.setVisibility(View.GONE);
                                notAssigned.setVisibility(View.GONE);
                                linear_content.setVisibility(View.VISIBLE);

                                Collections.sort(listItems, new Comparator<PlayListItem>() {
                                    @Override
                                    public int compare(PlayListItem item1, PlayListItem item2) {
                                        Long order1 = item1.getOrder();
                                        Long order2 = item2.getOrder();
                                        if (order1 < order2) return -1;
                                        else if (order1 > order2) return 1;
                                        else return 0;
                                    }
                                });

                                List<String> nameList = new ArrayList<>();
                                final List<File> childs = Arrays.asList(
                                        downFolder != null ? downFolder.listFiles() : new File[]{});

                                for (int j = 0; j < listItems.size(); j++) {
                                    PlayListItem playListItem = listItems.get(j);
                                    final List<Item> list = playListItem.getItems();
                                    Collections.sort(list, new Comparator<Item>() {
                                        @Override
                                        public int compare(Item item1, Item item2) {
                                            Long order1 = item1.getOrder();
                                            Long order2 = item2.getOrder();
                                            if (order1 < order2) return -1;
                                            else if (order1 > order2) return 1;
                                            else return 0;
                                        }
                                    });
                                    for (int i = 0; i < list.size(); i++) {
                                        Item item = list.get(i);
                                        String url = TraliusApiService.API_URL + item.getUrl();
                                        final String fileName = Util.getFileName(url);
                                        nameList.add(Util.getFileName(url));
                                        if (downFolder != null) {
                                            final File file = new File(downFolder, fileName);
                                            if (!childs.contains(file)) {
                                                try {
                                                    file.createNewFile();
                                                }
                                                catch (IOException e) {
                                                    e.printStackTrace();

                                                    new LovelyInfoDialog(MainActivity.this)
                                                            .setTopColorRes(colorError)
                                                            .setIcon(R.drawable.ic_error)
                                                            .setIconTintColor(Color.WHITE)
                                                            .setTitle(R.string.error)
                                                            .setTitleGravity(
                                                                    Gravity.CENTER_HORIZONTAL)
                                                            .setMessage(R.string.error_no_file)
                                                            .setConfirmButtonText(R.string.ok)
                                                            .configureView(
                                                                    new ViewConfigurator<View>() {
                                                                        @Override
                                                                        public void configureView
                                                                                (View v) {

                                                                            int padding = (int)
                                                                                    getResources()
                                                                                            .getDimension(

                                                                                                    R.dimen._5sdp);
                                                                            LinearLayout
                                                                                    ld_color_area
                                                                                    = v
                                                                                    .findViewById(
                                                                                            com
                                                                                                    .yarolegovich
                                                                                                    .lovelydialog
                                                                                                    .R.id
                                                                                                    .ld_color_area);
                                                                            ld_color_area
                                                                                    .setPadding(
                                                                                            0,
                                                                                            padding,
                                                                                            0,
                                                                                            padding);
                                                                        }
                                                                    })
                                                            .setConfirmButtonColor(
                                                                    ContextCompat.getColor(
                                                                            MainActivity.this,
                                                                            colorError))
                                                            .show();

                                                }
                                                final ProgressDialog dialog = new ProgressDialog(
                                                        MainActivity.this);
                                                dialog.setMessage(
                                                        getString(
                                                                R.string.downloading) + " " +
                                                                url);
                                                dialog.setIndeterminate(false);
                                                dialog.setMax(100);
                                                dialog.setProgressStyle(
                                                        ProgressDialog.STYLE_HORIZONTAL);
                                                dialog.setCancelable(false);
                                                dialog.setCanceledOnTouchOutside(false);
                                                dialog.show();

                                                Velocity.initialize(3);
                                                final int finalSum = sum;
                                                Velocity.download(url).setDownloadFile(
                                                        file.getAbsolutePath())
                                                        .withProgressListener(
                                                                new Velocity.ProgressListener
                                                                        () {
                                                                    @Override
                                                                    public void onFileProgress
                                                                            (int i) {
                                                                        dialog.setProgress(i);
                                                                    }
                                                                })
                                                        .connect(
                                                                new Velocity.ResponseListener
                                                                        () {
                                                                    @Override
                                                                    public void
                                                                    onVelocitySuccess
                                                                            (Velocity.Response
                                                                                     response) {
                                                                        String body =
                                                                                response.body;
                                                                        Log.wtf("Download",
                                                                                "onVelocitySuccess() " +
                                                                                        "returned: "
                                                                                        + body
                                                                                        .toString
                                                                                                ());
                                                                        dialog.dismiss();

                                                                        DOWNLOADS_COUNT++;
                                                                        if (DOWNLOADS_COUNT
                                                                                == finalSum)
                                                                            new Handler()
                                                                                    .postDelayed(
                                                                                            new
                                                                                                    Runnable() {
                                                                                                        @Override
                                                                                                        public void
                                                                                                        run() {
                                                                                                            runOnUiThread(
                                                                                                                    new Runnable() {
                                                                                                                        @Override
                                                                                                                        public void run() {
                                                                                                                            preferences.addBoolean(
                                                                                                                                    getString(
                                                                                                                                            R.string.pref_is_first_time),
                                                                                                                                    false);
                                                                                                                            preferences.save();

                                                                                                                            ShowData();
                                                                                                                            startActivity(
                                                                                                                                    new Intent(
                                                                                                                                            MainActivity.this,
                                                                                                                                            MainActivity.class));

                                                                                                                        }
                                                                                                                    });
                                                                                                        }
                                                                                                    },
                                                                                            1500);
                                                                    }

                                                                    @Override
                                                                    public void
                                                                    onVelocityFailed(Velocity
                                                                                             .Response
                                                                                             response) {
                                                                        Log.wtf("Download",
                                                                                "onVelocityFailed" +
                                                                                        "() " +
                                                                                        "returned:" +
                                                                                        " " +
                                                                                        response
                                                                                                .body
                                                                                                .toString
                                                                                                        ());
                                                                        file.delete();

                                                                        new LovelyInfoDialog(MainActivity.this)
                                                                                .setTopColorRes(colorError)
                                                                                .setIcon(R.drawable.ic_error)
                                                                                .setIconTintColor(Color.WHITE)
                                                                                .setTitle(R.string.error)
                                                                                .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                                                                                .setMessage(R.string.error_no_connection)
                                                                                .setConfirmButtonText(R.string.ok)
                                                                                .configureView(new ViewConfigurator<View>() {
                                                                                    @Override
                                                                                    public void configureView(View v) {
                                                                                        int padding = (int) getResources().getDimension(
                                                                                                R.dimen._5sdp);
                                                                                        LinearLayout ld_color_area = v.findViewById(
                                                                                                com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                                                                        ld_color_area.setPadding(0, padding, 0, padding);
                                                                                    }
                                                                                })
                                                                                .setConfirmButtonColor(ContextCompat.getColor(
                                                                                        MainActivity.this,
                                                                                        colorError))

                                                                                .show();


                                                                        dialog.dismiss();
                                                                    }
                                                                });
                                            }
                                            else {
                                                if (i == list.size() - 1) {
                                                    preferences.addBoolean(
                                                            getString(
                                                                    R.string.pref_is_first_time),
                                                            false);
                                                    preferences.save();

                                                    ShowData();
                                                    startActivity(
                                                            new Intent(
                                                                    MainActivity.this,
                                                                    MainActivity.class));
                                                }
                                            }

                                        }

                                    }
                                }
                                if (childs != null && !childs.isEmpty())
                                    for (File f : childs)
                                        if (!nameList.contains(f.getName()))
                                            f.delete();


                                Log.e("GetData",
                                      "onResponse: " + playListResult.getStatusCode() +
                                              "\n\nLISTAS " +
                                              "\nDE " +
                                              "REPRODUCCIÓN:\n" +
                                              result.toString());
                            }
                        }
                        else {
                            notData.setVisibility(View.VISIBLE);
                            notAssigned.setVisibility(View.GONE);
                            linear_content.setVisibility(View.GONE);
                        }
                    }
                    else
                        new LovelyInfoDialog(MainActivity.this)
                                .setTopColorRes(colorError)
                                .setIcon(R.drawable.ic_error)
                                .setIconTintColor(Color.WHITE)
                                .setTitle(R.string.error)
                                .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                                .setMessage(R.string.error_no_connection)
                                .setConfirmButtonText(R.string.ok)
                                .configureView(new ViewConfigurator<View>() {
                                    @Override
                                    public void configureView(View v) {
                                        int padding = (int) getResources().getDimension(
                                                R.dimen._5sdp);
                                        LinearLayout ld_color_area = v.findViewById(
                                                com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                        ld_color_area.setPadding(0, padding, 0, padding);
                                    }
                                })
                                .setConfirmButtonColor(ContextCompat.getColor(
                                        MainActivity.this,
                                        colorError))
                                .show();
                }

                @Override
                public void onFailure(Call<PlayListResult> call, Throwable t) {
                    Log.e("GetData", "onFailure error: " + t.getLocalizedMessage());

                    new LovelyInfoDialog(MainActivity.this)
                            .setTopColorRes(colorError)
                            .setIcon(R.drawable.ic_error)
                            .setIconTintColor(Color.WHITE)
                            .setTitle(R.string.error)
                            .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                            .setMessage(R.string.error_no_connection)
                            .setConfirmButtonText(R.string.ok)
                            .configureView(new ViewConfigurator<View>() {
                                @Override
                                public void configureView(View v) {
                                    int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                    LinearLayout ld_color_area = v.findViewById(
                                            com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                    ld_color_area.setPadding(0, padding, 0, padding);
                                }
                            })
                            .setConfirmButtonColor(ContextCompat.getColor(
                                    MainActivity.this,
                                    colorError))
                            .show();
                }
            });
            Snackbar.make(fab, R.string.getting_playlists, Snackbar.LENGTH_LONG)
                    .show();
        }
    }

    private void GetCompany() {
        Call<CompanyResult> call = apiConnection.GetSettings(SERIAL);
        call.enqueue(new Callback<CompanyResult>() {
            @Override
            public void onResponse(Call<CompanyResult> call, Response<CompanyResult> response) {

                Log.wtf("GetCompany", "onResponse() returned: " + call.request().url().toString());

                if (response.code() == 200) {

                    CompanyResult companyResult = response.body();
                    Log.e("GetCompany",
                          "onResponse: " + companyResult.getStatusCode() + "\n\nDATOS \nDE " +
                                  "LA EMPRESA:\n" +
                                  companyResult.toString());

                    if (companyResult.getStatusCode() == 200) {

                        preferences.addBoolean(getString(R.string.pref_is_assigned),
                                               true);
                        preferences.save();

                        com.imagine.tralius.service.data.company.Item item =
                                companyResult.getResult().getItem();


                        String primaryColor = item.getPrimaryColor();
                        String secondaryColor = item.getSecondaryColor();
                        String auxColor = item.getAuxColor();

                        final Colorful.ThemeColor primary = GetColor(primaryColor, true);
                        final Colorful.ThemeColor secondary = GetColor(secondaryColor, false);
                        final ThemeDelegate delegate = Colorful.getThemeDelegate();

                        preferences.addString(getString(R.string.pref_company_name),
                                              item.getCompanyName());
                        preferences.save();

                        text_company_name.setText(item.getCompanyName());

                        String logoUrl = item.getLogoUrl();
                        final String fileName = (logoUrl == null) ? "" : Util.getFileName(logoUrl);
                        if (logoFolder != null) {
                            final List<File> childs = Arrays.asList(logoFolder.listFiles());
                            final File file = new File(logoFolder, fileName);
                            if (!childs.contains(file)) {
                                try {
                                    file.createNewFile();
                                }
                                catch (IOException e) {
                                    e.printStackTrace();

                                }

                                String url = TraliusApiService.API_URL + logoUrl;
                                final ProgressDialog dialog = new ProgressDialog(
                                        MainActivity.this);
                                dialog.setMessage(
                                        getString(R.string.downloading) + " " + url);
                                dialog.setIndeterminate(false);
                                dialog.setMax(100);
                                dialog.setProgressStyle(
                                        ProgressDialog.STYLE_HORIZONTAL);
                                dialog.setCancelable(false);
                                dialog.setCanceledOnTouchOutside(false);
                                dialog.show();

                                Velocity.initialize(3);
                                Velocity.download(url).setDownloadFile(
                                        file.getAbsolutePath())
                                        .withProgressListener(
                                                new Velocity.ProgressListener() {
                                                    @Override
                                                    public void onFileProgress(int i) {
                                                        dialog.setProgress(i);
                                                    }
                                                })
                                        .connect(new Velocity.ResponseListener() {
                                            @Override
                                            public void onVelocitySuccess(Velocity.Response
                                                                                  response) {
                                                String body = response.body;
                                                Log.wtf("Download LOGO",
                                                        "onVelocitySuccess() returned: "
                                                                + body
                                                                .toString());
                                                dialog.dismiss();

                                                if (file.exists()) {

                                                    preferences.addString(
                                                            getString(
                                                                    R.string.pref_company_logo),
                                                            file.getAbsolutePath());
                                                    preferences.addBoolean(getString(
                                                            R.string.pref_is_company),
                                                                           true);
                                                    preferences.save();
                                                    if (delegate.getAccentColor() !=
                                                            secondary ||
                                                            delegate.getPrimaryColor
                                                                    () !=
                                                                    primary) {
                                                        Colorful.config(
                                                                MainActivity.this)
                                                                .primaryColor(primary)
                                                                .accentColor(secondary)
                                                                .translucent(false)
                                                                .dark(false)
                                                                .apply();
                                                    }
                                                    recreate();
                                                }
                                            }

                                            @Override
                                            public void onVelocityFailed(Velocity.Response
                                                                                 response) {
                                                Log.wtf("Download LOGO",
                                                        "onVelocityFailed() returned:" +
                                                                " " +
                                                                response.body
                                                                        .toString());
                                                dialog.dismiss();
                                            }
                                        });

                            }
                            else {
                                preferences.addString(
                                        getString(
                                                R.string.pref_company_logo),
                                        file.getAbsolutePath());
                                preferences.addBoolean(getString(
                                        R.string.pref_is_company),
                                                       true);
                                preferences.save();
                                if (delegate.getAccentColor() !=
                                        secondary ||
                                        delegate.getPrimaryColor
                                                () !=
                                                primary) {
                                    Colorful.config(
                                            MainActivity.this)
                                            .primaryColor(primary)
                                            .accentColor(secondary)
                                            .translucent(false)
                                            .dark(false)
                                            .apply();
                                }
                                recreate();
                            }

                            if (childs != null && !childs.isEmpty())
                                for (File f : childs) {
                                    if (!file.getName().equals(f.getName()))
                                        f.delete();
                                }

                        }

                    }

                    else if (companyResult.getStatusCode() == 404) {
                        Snackbar.make(fab, R.string.no_settings, Snackbar.LENGTH_LONG)
                                .show();
                    }
                }
                else
                    new LovelyInfoDialog(MainActivity.this)
                            .setTopColorRes(colorError)
                            .setIcon(R.drawable.ic_error)
                            .setIconTintColor(Color.WHITE)
                            .setTitle(R.string.error)
                            .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                            .setMessage(R.string.error_no_connection)
                            .setConfirmButtonText(R.string.ok)
                            .configureView(new ViewConfigurator<View>() {
                                @Override
                                public void configureView(View v) {
                                    int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                    LinearLayout ld_color_area = v.findViewById(
                                            com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                    ld_color_area.setPadding(0, padding, 0, padding);
                                }
                            })
                            .setConfirmButtonColor(ContextCompat.getColor(
                                    MainActivity.this,
                                    colorError))
                            .show();

            }

            @Override
            public void onFailure(Call<CompanyResult> call, Throwable t) {
                Log.wtf("GetCompany", "onResponse() returned: " + call.request().url().toString());
                Log.e("GetCompany", "onFailure error: " + t.getLocalizedMessage());

                new LovelyInfoDialog(MainActivity.this)
                        .setTopColorRes(colorError)
                        .setIcon(R.drawable.ic_error)
                        .setIconTintColor(Color.WHITE)
                        .setTitle(R.string.error)
                        .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                        .setMessage(R.string.error_no_connection)
                        .setConfirmButtonText(R.string.ok)
                        .configureView(new ViewConfigurator<View>() {
                            @Override
                            public void configureView(View v) {
                                int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                LinearLayout ld_color_area = v.findViewById(
                                        com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                ld_color_area.setPadding(0, padding, 0, padding);
                            }
                        })
                        .setConfirmButtonColor(ContextCompat.getColor(
                                MainActivity.this,
                                colorError))
                        .show();
            }
        });
        Snackbar.make(fab, R.string.getting_settings, Snackbar.LENGTH_LONG)
                .show();
    }

    private void ShowData() {
        effectList = new ArrayList<>();
        listTimes = new ArrayList<>();
        times = new ArrayList<>();
        listCaptions = new ArrayList<>();
        captions = new ArrayList<>();
        displayClocks = new ArrayList<>();
        contentFits = new ArrayList<>();
        nameList = new ArrayList<>();

        if (downFolder != null)
            fileList = Arrays.asList(downFolder.listFiles());

        final Result result = preferences.getObject(getString(R.string.pref_result), Result.class);
        if (result != null) {
            List<PlayListItem> playListItems = result.getPlayListItems();
            int size = playListItems.size();

            sizes = new int[size];

            Collections.sort(playListItems, new Comparator<PlayListItem>() {
                @Override
                public int compare(PlayListItem item1, PlayListItem item2) {
                    Long order1 = item1.getOrder();
                    Long order2 = item2.getOrder();
                    if (order1 < order2) return -1;
                    else if (order1 > order2) return 1;
                    else return 0;
                }
            });

            if (size == 0) {
                notData.setVisibility(View.VISIBLE);
                notAssigned.setVisibility(View.GONE);
                linear_content.setVisibility(View.GONE);
            }
            else {
                notData.setVisibility(View.GONE);
                notAssigned.setVisibility(View.GONE);
                linear_content.setVisibility(View.VISIBLE);
            }

            for (int i = 0; i < size; i++) {
                PlayListItem item = playListItems.get(i);
                List<Item> list = item.getItems();
                Collections.sort(list, new Comparator<Item>() {
                    @Override
                    public int compare(Item item1, Item item2) {
                        Long order1 = item1.getOrder();
                        Long order2 = item2.getOrder();
                        if (order1 < order2) return -1;
                        else if (order1 > order2) return 1;
                        else return 0;
                    }
                });
                int value = list.size();

                sizes[i] = (i == 0) ? value : value + sizes[i - 1];

                Setting setting = item.getSetting();
                List<Integer> effects = setting.getEffects();
                Random random = new Random();
                Long transitionTime = setting.getTransitionTime();
                if (transitionTime == 0 || transitionTime == null) {
                    transitionTime = 10L;
                }
                String caption = setting.getCaption();
                Boolean clock = setting.getDisplayClock();
                Boolean fit = setting.getContentFit();

                for (Item it : list) {
                    if (effects.size() != 0) {
                        effectList.add(effects.get(random.nextInt(effects.size())));
                    }
                    effectList.add(random.nextInt());
                    Long time = it.getTransitionTime();
                    if (time == 0 || time == null) time = 10L;
                    times.add(time * 1000);

                    listTimes.add(transitionTime * 1000);
                    captions.add(it.getCaption());
                    listCaptions.add(caption);
                    displayClocks.add(clock);
                    contentFits.add(fit);
                    nameList.add(Util.getFileName(it.getUrl()));
                }

            }

            videoList = new ArrayList<>();
            for (String fileName : nameList) {
                File file = new File(downFolder, fileName);
                String type = getFileType(file);
                videoList.add(type.contains("video") ? file.getAbsolutePath() : "");
            }

            frameVideoViewList = new ArrayList<>();
            players = new ArrayList<>();
            customCarouselView.setViewListener(new ViewListener() {

                @Override
                public View setViewForPosition(final int position) {

                    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                                         WindowManager.LayoutParams.FLAG_FULLSCREEN);

                    View customView;

                    String name = nameList.get(position);
                    final File file = new File(downFolder, name);
                    String type = getFileType(file);

                    if (type.contains("image")) {
                        customView = getLayoutInflater().inflate(R.layout.carousel_img, null);
                        ImageView imagen = customView.findViewById(R.id.imagen);

                        int size = (int) file.length();
                        byte[] bytes = new byte[size];
                        try {
                            BufferedInputStream buf = new BufferedInputStream(
                                    new FileInputStream(file));
                            buf.read(bytes, 0, bytes.length);
                            buf.close();
                            if (bytes != null) {

                                Glide.with(MainActivity.this).load(bytes).into(imagen);


                            }
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                            new LovelyInfoDialog(MainActivity.this)
                                    .setTopColorRes(colorError)
                                    .setIcon(R.drawable.ic_error)
                                    .setIconTintColor(Color.WHITE)
                                    .setTitle(R.string.error)
                                    .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                                    .setMessage(R.string.error_no_file)
                                    .setConfirmButtonText(R.string.ok)
                                    .configureView(new ViewConfigurator<View>() {
                                        @Override
                                        public void configureView(View v) {
                                            int padding = (int) getResources().getDimension(
                                                    R.dimen._5sdp);
                                            LinearLayout ld_color_area = v.findViewById(
                                                    com.yarolegovich.lovelydialog.R.id
                                                            .ld_color_area);
                                            ld_color_area.setPadding(0, padding, 0, padding);
                                        }
                                    })
                                    .setConfirmButtonColor(ContextCompat.getColor(
                                            MainActivity.this,
                                            colorError))
                                    .show();
                        }

                        frameVideoViewList.add(null);
                        players.add(null);

                    }
                    else {
                        customView = getLayoutInflater().inflate(R.layout.carousel_video, null);
                        frameVideoView = customView.findViewById(R.id.frame_video_view);
                        frameVideoView.setFrameVideoViewListener(new FrameVideoViewListener() {

                            @Override
                            public void mediaPlayerPrepared(final MediaPlayer mediaPlayer) {
                                mediaPlayer.start();

                                mediaPlayer.setOnCompletionListener(
                                        new MediaPlayer.OnCompletionListener() {
                                            @Override
                                            public void onCompletion(MediaPlayer mp) {
                                                mp.stop();
                                                mediaPlayer.reset();
                                            }
                                        });
                            }

                            @Override
                            public void mediaPlayerPrepareFailed(MediaPlayer mediaPlayer, String
                                    error) {
                            }
                        });

                        frameVideoViewList.add(frameVideoView);
                        if (first && type.contains("video")) {
                            String video = videoList.get(position);
                            frameVideoView.setup(Uri.parse(video));
                            frameVideoView.setFrameVideoViewListener(new FrameVideoViewListener() {
                                @Override
                                public void mediaPlayerPrepared(MediaPlayer mp) {
                                    mp.setVolume(0, 0);
                                    players.add(mp);
                                    mp.start();
                                    int time = mp.getDuration();
                                    customCarouselView.reSetSlideInterval(time);
                                    Log.wtf("0 TIME", "onPrepared() returned: " + time);
                                    frameVideoView.setVisibility(View.VISIBLE);
                                }

                                @Override
                                public void mediaPlayerPrepareFailed(MediaPlayer mediaPlayer,
                                                                     String s) {

                                }
                            });
                            first = false;
                        }

                    }

                    if (!captions.isEmpty() && position < captions.size()) {
                        TextView item_caption = customView.findViewById(R.id.item_caption);
                        item_caption.setText(captions.get(position));
                    }

                    customView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onTouch(v);
                        }
                    });
                    return customView;
                }


            });
            customCarouselView.addOnPageChangeListener(

                    new ViewPager.OnPageChangeListener() {
                        @Override
                        public void onPageScrolled(int position, float positionOffset, int
                                positionOffsetPixels) { }

                        @Override
                        public void onPageSelected(final int position) {
                            currentPos = savedInstanceState != null
                                         ? savedInstanceState.getInt(
                                    getString(R.string.pref_current_pos), -1)
                                         : position;
                            Log.wtf("CURRENT",
                                    savedInstanceState + " --> currentPos:" + currentPos + " " +
                                            "position:" + position);
                            if (fileList != null) {

                                String name = nameList.get(currentPos);
                                final File file = new File(downFolder, name);

                                StopPlaying();
                                boolean isVideo = getFileType(file).contains("video");

                                if (isVideo) {

                                    if (currentPos > 0 &&
                                            getFileType(new File(file.getParent(),
                                                                 nameList.get(currentPos - 1)))
                                                    .contains("video")) {
                                        Log.wtf("VIDEOS SEGUIDOS",
                                                (currentPos - 1) + " " + currentPos);
                                        frameVideoViewList.get(currentPos - 1).setVisibility(
                                                View.INVISIBLE);
                                    }

                                    FrameVideoView videoView = frameVideoViewList.get(currentPos);
                                    videoView.setVisibility(View.VISIBLE);
                                    videoView.setup(Uri.parse(videoList.get(currentPos)));
                                    videoView.setFrameVideoViewListener(
                                            new FrameVideoViewListener() {
                                                @Override
                                                public void mediaPlayerPrepared(MediaPlayer mp) {
                                                    mp.setVolume(0, 0);
                                                    mp.start();
                                                    int time = mp.getDuration() + 100;
                                                    customCarouselView.reSetSlideInterval(time);
                                                    Log.wtf("!=0 TIME",
                                                            "onPrepared() returned: " + time);
                                                }

                                                @Override
                                                public void mediaPlayerPrepareFailed(MediaPlayer
                                                                                             mediaPlayer, String s) {

                                                }
                                            });
                                }


                                if (sizes != null) {
                                    tvListCaption.setText(listCaptions.get(currentPos));

                                    long t = times.get(currentPos);
                                    long lt = listTimes.get(currentPos);
                                    if (currentPos < times.size() - 1 && lt != listTimes.get(
                                            currentPos + 1))
                                        t += lt;
                                    Log.wtf("TIME",
                                            "onPageSelected() returned: " + position + " - " + t);
                                    SetTransitionEffect(effectList.get(currentPos), t);

                                }
                            }

                        }

                        @Override
                        public void onPageScrollStateChanged(int state) { }
                    });

            if (sizes != null && sizes.length > 0) {
                customCarouselView.setPageCount(times.size());
                tvListCaption.setText(listCaptions.get(0));
                SetTransitionEffect(effectList.get(0), times.get(0));
            }
        }
        else {
            notData.setVisibility(View.VISIBLE);
            notAssigned.setVisibility(View.GONE);
            linear_content.setVisibility(View.GONE);
        }
    }

    private void StopPlaying() {
        if (frameVideoViewList != null)
            for (FrameVideoView fvv : frameVideoViewList) {
                if (fvv != null)
                    fvv.onPause();
            }
        /*if (players != null)
            for (MediaPlayer mp : players) {
                if (mp != null && mp.isPlaying())
                    mp.pause();
            }*/
    }

    private void SignalR() {
        try {
            String url = "http://app.tralius.com/signalr/hubs";

            con = new HubConnection(url, this, new LongPollingTransport()) {
                @Override
                public void OnStateChanged(StateBase oldState, StateBase newState) {

                    switch (newState.getState()) {
                        case Connected:
                            Log.wtf("STATUS", "OnStateChanged() returned: CONNECTED");
                            List<String> list = new ArrayList<>();
                            list.add(SERIAL);
                            String connectionId = con.getConnectionId();
                            list.add(connectionId);
                            hub.Invoke("connect", list, new HubInvokeCallback() {
                                @Override
                                public void OnResult(boolean succeeded, String response) {
                                    Log.wtf("CONNECT", "OnResult() returned: OK");
                                }

                                @Override
                                public void OnError(Exception ex) {
                                    Log.wtf("CONNECT",
                                            "OnError() returned: " + ex.getMessage());
                                }
                            });
                            break;
                        case Disconnected:
                            Log.wtf("STATUS", "OnStateChanged() returned: DISCONNECTED");
                            break;
                        default:
                            break;
                    }
                }

            };
            con.setUrl(con.GetUrl(url, false));

            hub = con.CreateHubProxy("traliusHub");

            con.Start();

            hub.On("notify", new HubOnDataCallback() {
                @Override
                public void OnReceived(JSONArray args) {
                    try {
                        if (args != null) {
                            Object opt = args.opt(0);
                            if (opt != null) {
                                int result = Integer.parseInt(opt.toString());
                                Log.wtf("NOTIFY", "OnReceived() returned: " + result);

                                switch (result) {
                                    case 1:

                                        if (contentUpdateMenuItem != null)
                                            contentUpdateMenuItem.setVisible(!SERIAL.isEmpty());

                                        preferences.addBoolean(getString(R.string.pref_is_assigned),
                                                               true);
                                        preferences.save();

                                        notData.setVisibility(View.VISIBLE);
                                        notAssigned.setVisibility(View.GONE);
                                        linear_content.setVisibility(View.GONE);

                                        if (serialDialog != null && serialDialog.isShowing())
                                            serialDialog.dismiss();

                                        new LovelyInfoDialog(MainActivity.this)
                                                .setTopColorRes(colorInfo)
                                                .setTopTitle(R.string.device_added_title)
                                                .setMessageGravity(Gravity.CENTER_HORIZONTAL)
                                                .setMessage(R.string.device_added_message)
                                                .setConfirmButtonText(R.string.ok)
                                                .setConfirmButtonColor(ContextCompat.getColor(
                                                        MainActivity.this,
                                                        colorInfo))
                                                .configureView(new ViewConfigurator<View>() {
                                                    @Override
                                                    public void configureView(View v) {

                                                        int padding = (int) getResources()
                                                                .getDimension(
                                                                        R.dimen._5sdp);
                                                        LinearLayout ld_color_area = v.findViewById(
                                                                com.yarolegovich.lovelydialog.R
                                                                        .id.ld_color_area);
                                                        ld_color_area.setPadding(0, padding, 0,
                                                                                 padding);

                                                        TextView ld_message = v.findViewById(
                                                                com.yarolegovich.lovelydialog.R
                                                                        .id.ld_message);
                                                        TextView ld_top_title = v.findViewById(
                                                                com.yarolegovich.lovelydialog.R
                                                                        .id.ld_top_title);

                                                        ld_message.setTextAppearance(
                                                                MainActivity.this,
                                                                android.R.style
                                                                        .TextAppearance_Material_Display1);

                                                        ld_message.setTypeface(
                                                                Typeface.DEFAULT_BOLD);
                                                        ld_top_title.setTextAppearance(
                                                                MainActivity.this,
                                                                android.R.style
                                                                        .TextAppearance_Material_Large);
                                                    }
                                                })
                                                .show();

                                        break;
                                    case 2:
                                        GetCompany();
                                        break;
                                    case 3:
                                        GetData();
                                        break;
                                    case 4:
                                        if (!SERIAL.isEmpty()) {
                                            SetNotAssigned();
                                        }
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            });

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void copyToClipboard(Context context, String text) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES
                .HONEYCOMB) {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager)
                    context.getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText(null, text));
        }
        else {
            android.content.ClipboardManager clipboard = (android.content
                    .ClipboardManager)
                    context.getSystemService(
                            Context.CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText(
                    context.getString(android.R.string.copy),
                    text);
            clipboard.setPrimaryClip(clip);
        }
    }

    private String FormatSerial(String serial) {
        String p1 = serial.substring(0, 4);
        String p2 = serial.substring(4, 8);
        String p3 = serial.substring(8, 12);
        String p4 = serial.substring(12);
        return p1 + " - " + p2 + " - " + p3 + " - " + p4;
    }

    private void SetTransitionEffect(int idEffect, long interval) {
        ViewPager.PageTransformer transformer = new DefaultTransformer();
        switch (idEffect) {
            case 2:
                transformer = new BackgroundToForegroundTransformer();
                break;
            case 3:
                transformer = new ForegroundToBackgroundTransformer();
                break;
            case 4:
                transformer = new CubeInTransformer();
                break;
            case 5:
                transformer = new CubeOutTransformer();
                break;
            case 6:
                transformer = new AccordionTransformer();
                break;
            case 7:
                transformer = new DepthPageTransformer();
                break;
            case 8:
                transformer = new FlipHorizontalTransformer();
                break;
            case 9:
                transformer = new FlipVerticalTransformer();
                break;
            case 10:
                transformer = new RotateDownTransformer();
                break;
            case 11:
                transformer = new RotateUpTransformer();
                break;
            case 12:
                transformer = new ScaleInOutTransformer();
                break;
            case 13:
                transformer = new StackTransformer();
                break;
            case 14:
                transformer = new TabletTransformer();
                break;
            case 15:
                transformer = new ZoomInTransformer();
                break;
            case 16:
                transformer = new ZoomOutTranformer();
                break;
            case 17:
                transformer = new ZoomOutSlideTransformer();
                break;
            default:
                break;
        }

        customCarouselView.setPageTransformer(transformer);
        customCarouselView.reSetSlideInterval((int) interval);
    }

    @Override
    protected void onPause() {
        if (wifiReciever != null)
            unregisterReceiver(wifiReciever);
        super.onPause();
    }

    @Override
    public void onResume() {

        IntentFilter filter = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        filter.addAction(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION);

        if (wifiReciever != null)
            registerReceiver(wifiReciever, filter);

        StopPlaying();

        super.onResume();
    }

    class WifiScanReceiver extends BroadcastReceiver {

        @SuppressLint("UseValueOf")
        public void onReceive(Context c, Intent intent) {
            String action = intent.getAction();
            if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {

                List<ScanResult> wifiScanList = mainWifiObj.getScanResults();

                Log.wtf("TIME---->", "" + System.currentTimeMillis());
                Log.wtf("WIFIS---->", "" + wifiScanList.size());

                WifiAdapter wifiAdapter = new WifiAdapter(MainActivity.this, R.layout.custom_wifi,
                                                          wifiScanList);
                LovelyChoiceDialog.OnItemSelectedListener<ScanResult> selectedListener = new
                        LovelyChoiceDialog.OnItemSelectedListener<ScanResult>() {
                            @Override
                            public void onItemSelected(int position, ScanResult item) {
                                if (dialog != null) dialog.dismiss();
                                if (handler != null)
                                    handler.removeCallbacksAndMessages(null);
                                handler = null;

                                String capabilities = item.capabilities;
                                Log.wtf("capabilities", "" + capabilities);
                                if (capabilities.contains("WPA") ||
                                        capabilities.contains("WPA2") ||
                                        capabilities.contains("WEP"))
                                    connectToWifi(item.SSID);
                            }
                        };

                if (handler != null) {
                    if (dialog == null)

                        dialog = new LovelyChoiceDialog(MainActivity.this)
                                .setTopColorRes(colorInfo)
                                .setTitle(R.string.available_networks)
                                .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                                .setIcon(R.drawable.ic_wifi)
                                .setIconTintColor(Color.WHITE)
                                .setItems(wifiAdapter, selectedListener)
                                .setCancelable(true)
                                .configureView(new ViewConfigurator<View>() {
                                    @Override
                                    public void configureView(View v) {
                                        int padding = (int) getResources().getDimension(
                                                R.dimen._5sdp);
                                        LinearLayout ld_color_area = v.findViewById(
                                                com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                        ld_color_area.setPadding(0, padding, 0, padding);
                                    }
                                });

                    else {dialog.setItems(wifiAdapter, selectedListener);}

                    Dialog show = dialog.show();
                    show.setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (dialog != null) dialog.dismiss();
                            if (handler != null)
                                handler.removeCallbacksAndMessages(null);
                            handler = null;
                        }
                    });
                }
            }
            else {
                Log.wtf("WifiReceiver", ">>>>SUPPLICANT_STATE_CHANGED_ACTION<<<<<<");
                SupplicantState supl_state = intent.getParcelableExtra(WifiManager.EXTRA_NEW_STATE);
                switch (supl_state) {
                    case ASSOCIATED:
                        Log.wtf("SupplicantState", "ASSOCIATED");
                        break;
                    case ASSOCIATING:
                        Log.wtf("SupplicantState", "ASSOCIATING");
                        break;
                    case AUTHENTICATING:
                        Log.wtf("SupplicantState", "Authenticating...");
                        break;
                    case COMPLETED:
                        Log.wtf("SupplicantState", "Connected");
                        break;
                    case DISCONNECTED:
                        Log.wtf("SupplicantState", "Disconnected");
                        break;
                    case DORMANT:
                        Log.wtf("SupplicantState", "DORMANT");
                        break;
                    case FOUR_WAY_HANDSHAKE:
                        Log.wtf("SupplicantState", "FOUR_WAY_HANDSHAKE");
                        break;
                    case GROUP_HANDSHAKE:
                        Log.wtf("SupplicantState", "GROUP_HANDSHAKE");
                        break;
                    case INACTIVE:
                        Log.wtf("SupplicantState", "INACTIVE");
                        break;
                    case INTERFACE_DISABLED:
                        Log.wtf("SupplicantState", "INTERFACE_DISABLED");
                        break;
                    case INVALID:
                        Log.wtf("SupplicantState", "INVALID");
                        break;
                    case SCANNING:
                        Log.wtf("SupplicantState", "SCANNING");
                        break;
                    case UNINITIALIZED:
                        Log.wtf("SupplicantState", "UNINITIALIZED");
                        break;
                    default:
                        Log.wtf("SupplicantState", "Unknown");
                        break;

                }
                int supl_error = intent.getIntExtra(WifiManager.EXTRA_SUPPLICANT_ERROR, -1);
                if (supl_error == WifiManager.ERROR_AUTHENTICATING) {
                    Log.wtf("ERROR_AUTHENTICATING",
                            "ERROR_AUTHENTICATING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

                    new LovelyInfoDialog(MainActivity.this)
                            .setTopColorRes(colorError)
                            .setIcon(R.drawable.ic_error)
                            .setIconTintColor(Color.WHITE)
                            .setTitle(R.string.error)
                            .setTitleGravity(Gravity.CENTER_HORIZONTAL)
                            .setMessage(R.string.error_wrong_password)
                            .configureView(new ViewConfigurator<View>() {
                                @Override
                                public void configureView(View v) {
                                    int padding = (int) getResources().getDimension(R.dimen._5sdp);
                                    LinearLayout ld_color_area = v.findViewById(
                                            com.yarolegovich.lovelydialog.R.id.ld_color_area);
                                    ld_color_area.setPadding(0, padding, 0, padding);
                                }
                            })
                            .setConfirmButtonText(R.string.ok)
                            .setConfirmButtonColor(ContextCompat.getColor(
                                    MainActivity.this,
                                    colorError))
                            .show();
                }
            }
        }

    }

    private void finallyConnect(String networkPass, String networkSSID) {
        WifiConfiguration wifiConfig = new WifiConfiguration();
        wifiConfig.SSID = String.format("\"%s\"", networkSSID);
        wifiConfig.preSharedKey = String.format("\"%s\"", networkPass);

        // remember id
        int netId = mainWifiObj.addNetwork(wifiConfig);
        mainWifiObj.disconnect();
        mainWifiObj.enableNetwork(netId, true);
        mainWifiObj.reconnect();

        WifiConfiguration conf = new WifiConfiguration();
        conf.SSID = "\"\"" + networkSSID + "\"\"";
        conf.preSharedKey = "\"" + networkPass + "\"";

        mainWifiObj.addNetwork(wifiConfig);
    }

    private void connectToWifi(final String wifiSSID) {

        new LovelyTextInputDialog(this, R.style.WifiEditTextTintTheme)
                .setTopColorRes(colorInfo)
                .setIcon(R.drawable.ic_wifi)
                .setIconTintColor(Color.WHITE)
                .setHint(R.string.password)
                .setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .setTitle(R.string.connect)
                .setMessage(wifiSSID)
                .configureView(new ViewConfigurator<View>() {
                    @Override
                    public void configureView(View v) {
                        int padding = (int) getResources().getDimension(R.dimen._5sdp);
                        LinearLayout ld_color_area = v.findViewById(
                                com.yarolegovich.lovelydialog.R.id.ld_color_area);
                        ld_color_area.setPadding(0, padding, 0, padding);
                    }
                })
                .setInputFilter(R.string.error_character_amount,
                                new LovelyTextInputDialog.TextFilter() {
                                    @Override
                                    public boolean check(String text) {
                                        return text.length() >= 8;
                                    }
                                })
                .setConfirmButton(R.string.ok,
                                  new LovelyTextInputDialog.OnTextInputConfirmListener() {
                                      @Override
                                      public void onTextInputConfirmed(String text) {
                                          finallyConnect(text, wifiSSID);
                                      }
                                  })
                .show();
    }

    private Colorful.ThemeColor GetColor(String color, boolean isPrimary) {
        try {
            String upperCase = color.toUpperCase();
            return Colorful.ThemeColor.valueOf(upperCase);
        }
        catch (IllegalArgumentException ex) {
            Snackbar.make(fab, R.string.error_invalid_color, Snackbar.LENGTH_LONG)
                    .show();
            ThemeDelegate themeDelegate = Colorful.getThemeDelegate();
            Colorful.ThemeColor primaryColor = themeDelegate.getPrimaryColor();
            Colorful.ThemeColor accentColor = themeDelegate.getAccentColor();
            Log.wtf("GetColor()", primaryColor.name() + " " + accentColor.name());
            return isPrimary ? primaryColor : accentColor;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(getString(R.string.pref_current_pos), currentPos);
    }

    private void SetNotAssigned() {
        SERIAL = "";
        notData.setVisibility(View.GONE);
        notAssigned.setVisibility(View.VISIBLE);
        linear_content.setVisibility(View.GONE);
        preferences.clearAll();
        preferences.save();
        File[] files = downFolder.listFiles();
        for (File f : files)
            f.delete();
        files = logoFolder.listFiles();
        for (File f : files)
            f.delete();
        if (contentUpdateMenuItem != null)
            contentUpdateMenuItem.setVisible(!SERIAL.isEmpty());

        Colorful.config(
                MainActivity.this)
                .primaryColor(Colorful.Defaults.getPrimaryColor())
                .accentColor(Colorful.Defaults.getAccentColor())
                .translucent(false)
                .dark(false)
                .apply();
        recreate();
    }

    public void onTouch(View view) {
        showActionBar();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                hideActionBar();


            }
        }, 2000);
    }

    protected void hideActionBar() {
        final ActionBar ab = getSupportActionBar();
        if (ab != null && ab.isShowing()) {
            if (toolbar != null) {
                toolbar.animate().translationY(-112).setDuration(600L)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                ab.hide();
                            }
                        }).start();
            }
            else {
                ab.hide();
            }
        }
    }

    protected void showActionBar() {
        ActionBar ab = getSupportActionBar();
        if (ab != null && !ab.isShowing()) {
            ab.show();
            if (toolbar != null) {
                toolbar.animate().translationY(0).setDuration(600L).start();
            }
        }
    }

    private void InstallNewVersion(String url) {

        String fileName = Util.getFileName(url);
        int start = fileName.lastIndexOf("_v") + 2;
        int end = fileName.lastIndexOf(".apk");
        String substring = fileName.substring(start, end);

        try {
            final double version = Double.parseDouble(substring);
            final File file = new File(traliusFolder, fileName);

            if (!file.exists())
                try {
                    file.createNewFile();

                    final ProgressDialog dialog = new ProgressDialog(
                            MainActivity.this);
                    dialog.setMessage(
                            getString(
                                    R.string.downloading) + " " +
                                    url);
                    dialog.setIndeterminate(false);
                    dialog.setMax(100);
                    dialog.setProgressStyle(
                            ProgressDialog.STYLE_HORIZONTAL);
                    dialog.setCancelable(false);
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();

                    Velocity.initialize(4);

                    Velocity.download(url).setDownloadFile(
                            file.getAbsolutePath())
                            .withProgressListener(
                                    new Velocity.ProgressListener
                                            () {
                                        @Override
                                        public void onFileProgress
                                                (int i) {
                                            dialog.setProgress(i);
                                        }
                                    })
                            .connect(
                                    new Velocity.ResponseListener
                                            () {
                                        @Override
                                        public void
                                        onVelocitySuccess
                                                (Velocity.Response
                                                         response) {
                                            String body =
                                                    response.body;
                                            Log.wtf("Download",
                                                    "onVelocitySuccess() " +
                                                            "returned: "
                                                            + body
                                                            .toString
                                                                    ());
                                            dialog.dismiss();

                                            Install(file, version);
                                        }

                                        @Override
                                        public void
                                        onVelocityFailed(Velocity
                                                                 .Response
                                                                 response) {
                                            Log.wtf("Download",
                                                    "onVelocityFailed" +
                                                            "() " +
                                                            "returned:" +
                                                            " " +
                                                            response
                                                                    .body
                                                                    .toString
                                                                            ());

                                            dialog.dismiss();
                                        }
                                    });


                }
                catch (IOException e) {
                    e.printStackTrace();
                }

            else
                Install(file, version);

        }
        catch (NumberFormatException e) {
            e.printStackTrace();
        }

    }

    private void Install(File file, double version) {
        ClearUpdates(file.getName());
        try {
            PackageInfo pInfo = MainActivity.this
                    .getPackageManager()
                    .getPackageInfo(
                            getPackageName(), 0);
            double currentVersion = Double.parseDouble(
                    pInfo.versionName);

            if (version > currentVersion) {

                PrefUtils.setKioskModeActive(false, MainActivity.this);

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.fromFile(file),
                                      "application/vnd" +
                                              ".android" +
                                              ".package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivityForResult(intent, INSTALL_REQUEST_CODE);
            }
            else
                Snackbar.make(fab, R.string.no_update,
                              Snackbar.LENGTH_LONG)
                        .show();

        }
        catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == INSTALL_REQUEST_CODE/* && resultCode == RESULT_CANCELED*/) {
            PrefUtils.setKioskModeActive(true, this);

        }
    }
}