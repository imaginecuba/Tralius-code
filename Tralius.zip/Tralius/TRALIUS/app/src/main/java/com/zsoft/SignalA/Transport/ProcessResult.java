package com.zsoft.SignalA.Transport;

public class ProcessResult
{
	public boolean timedOut = false;
	public boolean disconnected = false;
	public boolean initialized = false;
	public boolean processingFailed = false;
}
