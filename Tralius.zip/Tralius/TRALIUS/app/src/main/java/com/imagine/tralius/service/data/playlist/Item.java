package com.imagine.tralius.service.data.playlist;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

/**
 * Created by Elvis on 2/12/2018.
 */

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Item {

    @SerializedName("Caption")
    private String caption;
    @SerializedName("TransitionTime")
    private Long transitionTime;
    @SerializedName("Url")
    private String url;
    @SerializedName("Order")
    private Long order;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Long getTransitionTime() {
        return transitionTime;
    }

    public void setTransitionTime(Long transitionTime) {
        this.transitionTime = transitionTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }


    @Override
    public String toString() {
        return "Item{\n" +
                "caption='" + caption + '\'' +
                ", \ntransitionTime=" + transitionTime +
                ", \nurl='" + url + '\'' +
                ", \norder=" + order +
                "\n}";
    }
}
