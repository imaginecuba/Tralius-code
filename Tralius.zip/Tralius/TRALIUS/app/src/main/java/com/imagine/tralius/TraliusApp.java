package com.imagine.tralius;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.support.multidex.MultiDex;
import com.imagine.tralius.kiosko.KioskService;
import com.imagine.tralius.kiosko.OnScreenOffReceiver;
import com.imagine.tralius.util.ConnectivityReceiver;

import org.polaric.colorful.Colorful;

/**
 * Created by Elvis on 2/8/2018.
 */

public class TraliusApp extends Application {

    private PowerManager.WakeLock wakeLock;
    private OnScreenOffReceiver onScreenOffReceiver;

    private static TraliusApp mInstance;

    public static synchronized TraliusApp getInstance() {
        return mInstance;
    }

    public void setConnectivityListener(ConnectivityReceiver.ConnectivityReceiverListener
                                                listener) {
        ConnectivityReceiver.connectivityReceiverListener = listener;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        MultiDex.install(TraliusApp.this);
        Colorful.init(TraliusApp.this);
        registerKioskModeScreenOffReceiver();
        startKioskService();

    }

    private void registerKioskModeScreenOffReceiver() {
        final IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        onScreenOffReceiver = new OnScreenOffReceiver();
        registerReceiver(onScreenOffReceiver, filter);
    }

    public PowerManager.WakeLock getWakeLock() {
        if(wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "wakeup");
        }
        return wakeLock;
    }

    private void startKioskService() {
        startService(new Intent(this, KioskService.class));
    }

}
