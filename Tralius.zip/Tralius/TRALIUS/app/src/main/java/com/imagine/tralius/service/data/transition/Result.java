
package com.imagine.tralius.service.data.transition;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Result {

    @SerializedName("Items")
    private List<Effect> effectList;

    public List<Effect> getEffectList() {
        return effectList;
    }

    public void setEffectList(List<Effect> effectList) {
        this.effectList = effectList;
    }

    @Override
    public String toString() {
        String result = "";
        for (Effect i : effectList) {
            result += i.toString();
        }
        return result;
    }
}
