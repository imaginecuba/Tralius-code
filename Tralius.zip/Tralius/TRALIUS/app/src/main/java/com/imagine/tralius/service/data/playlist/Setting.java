
package com.imagine.tralius.service.data.playlist;

import com.google.gson.annotations.SerializedName;
import com.imagine.tralius.service.data.transition.Effect;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Setting {

    @SerializedName("Caption")
    private String caption;
    @SerializedName("ContentFit")
    private Boolean contentFit;
    @SerializedName("DisplayClock")
    private Boolean displayClock;
    @SerializedName("Effects")
    private List<Integer> effects;
    @SerializedName("Order")
    private Long order;
    @SerializedName("TransitionTime")
    private Long transitionTime;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Boolean getContentFit() {
        return contentFit;
    }

    public void setContentFit(Boolean contentFit) {
        this.contentFit = contentFit;
    }

    public Boolean getDisplayClock() {
        return displayClock;
    }

    public void setDisplayClock(Boolean displayClock) {
        this.displayClock = displayClock;
    }

    public List<Integer> getEffects() {
        return effects;
    }

    public void setEffects(List<Integer> effects) {
        this.effects = effects;
    }

    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }

    public Long getTransitionTime() {
        return transitionTime;
    }

    public void setTransitionTime(Long transitionTime) {
        this.transitionTime = transitionTime;
    }


    @Override
    public String toString() {
        return "Setting{\n" +
                "caption='" + caption + '\'' +
                ", \ncontentFit=" + contentFit +
                ", \ndisplayClock=" + displayClock +
                ", \neffects=" + effects +
                ", \norder=" + order +
                ", \ntransitionTime=" + transitionTime +
                "\n}";
    }
}
