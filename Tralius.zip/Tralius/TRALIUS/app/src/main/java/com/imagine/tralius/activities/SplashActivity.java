package com.imagine.tralius.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;

import com.imagine.tralius.R;
import com.imagine.tralius.kiosko.KioskoModeActivity;

import org.polaric.colorful.Colorful;

import fr.castorflex.android.smoothprogressbar.SmoothProgressBar;
import fr.castorflex.android.smoothprogressbar.SmoothProgressDrawable;

/**
 * Created by Elvis on 11/2/2017.
 */

public class SplashActivity extends KioskoModeActivity {


    public SplashActivity() {

    }

    @Override
    public void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Colorful.applyTheme(SplashActivity.this);

        setContentView(R.layout.activity_splash);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        final SmoothProgressBar mprogressBar = new SmoothProgressBar(SplashActivity.this);
        mprogressBar.setIndeterminateDrawable(new SmoothProgressDrawable.Builder(this)
                                                      .color(ContextCompat.getColor(
                                                              SplashActivity.this,
                                                              Colorful.getThemeDelegate()
                                                                      .getAccentColor()
                                                                      .getColorRes()))
                                                      .interpolator(new DecelerateInterpolator())
                                                      .sectionsCount(6)
                                                      .separatorLength(8)
                                                      .strokeWidth(8f)
                                                      .speed(2f)
                                                      .progressiveStartSpeed(2)
                                                      .progressiveStopSpeed(3.4f)
                                                      .reversed(false)
                                                      .mirrorMode(false)
                                                      .progressiveStart(true)
                                                      .callbacks(
                                                              new SmoothProgressDrawable
                                                                      .Callbacks() {
                                                                  public void onStop() {

                                                                  }

                                                                  @Override
                                                                  public void onStart() {
                                                                      Log.wtf("progressbar",
                                                                              "start");
                                                                      new Handler().postDelayed(
                                                                              new Runnable() {
                                                                                  @Override
                                                                                  public void run
                                                                                          () {
                                                                                      mprogressBar.progressiveStop();
                                                                                      Log.wtf("progressbar",
                                                                                              "stop");
                                                                                      Intent intent = new Intent(
                                                                                              SplashActivity.this,
                                                                                              MainActivity.class);
                                                                                      startActivity(
                                                                                              intent);
                                                                                      finish();
                                                                                  }
                                                                              }, 3000);
                                                                  }
                                                              })
                                                      .build());
        mprogressBar.progressiveStart();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mprogressBar.progressiveStop();
            }
        }, 3000);


    }
}
