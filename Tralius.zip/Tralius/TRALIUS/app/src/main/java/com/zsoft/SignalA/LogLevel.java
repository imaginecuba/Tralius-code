package com.zsoft.SignalA;

public enum LogLevel
{
	Debug,
	Verbose,
	Warning,
	Error
}
