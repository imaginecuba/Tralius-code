
package com.imagine.tralius.service.data.playlist;

import com.imagine.tralius.service.data.Error;
import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class PlayListResult {

    @SerializedName("Error")
    private com.imagine.tralius.service.data.Error error;
    @SerializedName("Result")
    private com.imagine.tralius.service.data.playlist.Result result;
    @SerializedName("StatusCode")
    private Long statusCode;

    public Object getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public com.imagine.tralius.service.data.playlist.Result getResult() {
        return result;
    }

    public void setResult(com.imagine.tralius.service.data.playlist.Result result) {
        this.result = result;
    }

    public Long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Long StatusCode) {
        this.statusCode = StatusCode;
    }

    @Override
    public String toString() {
        return "PlayListResult{" +
                "error=" + error +
                ", result=" + result +
                ", statusCode=" + statusCode +
                '}';
    }
}
