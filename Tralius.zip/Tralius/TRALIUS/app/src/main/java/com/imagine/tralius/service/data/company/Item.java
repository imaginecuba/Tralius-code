
package com.imagine.tralius.service.data.company;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Item {

    @SerializedName("AuxColor")
    private String auxColor;
    @SerializedName("CompanyName")
    private String companyName;
    @SerializedName("LogoUrl")
    private String logoUrl;
    @SerializedName("PrimaryColor")
    private String primaryColor;
    @SerializedName("SecondaryColor")
    private String secondaryColor;

    public String getAuxColor() {
        return auxColor;
    }

    public void setAuxColor(String auxColor) {
        this.auxColor = auxColor;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public String getPrimaryColor() {
        return primaryColor;
    }

    public void setPrimaryColor(String primaryColor) {
        this.primaryColor = primaryColor;
    }

    public String getSecondaryColor() {
        return secondaryColor;
    }

    public void setSecondaryColor(String secondaryColor) {
        this.secondaryColor = secondaryColor;
    }

    @Override
    public String toString() {
        return "Item{" +
                "auxColor='" + auxColor + '\'' +
                ", companyName='" + companyName + '\'' +
                ", logoUrl=" + logoUrl +
                ", primaryColor='" + primaryColor + '\'' +
                ", secondaryColor='" + secondaryColor + '\'' +
                '}';
    }
}
