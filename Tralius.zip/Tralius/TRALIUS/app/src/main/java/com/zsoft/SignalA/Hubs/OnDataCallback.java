package com.zsoft.SignalA.Hubs;

import org.json.JSONObject;

public abstract class OnDataCallback {
	public abstract JSONObject Callback(JSONObject result);

}
