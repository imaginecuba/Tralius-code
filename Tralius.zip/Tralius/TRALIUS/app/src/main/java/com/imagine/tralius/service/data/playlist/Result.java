
package com.imagine.tralius.service.data.playlist;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Result {

    @SerializedName("Items")
    private List<PlayListItem> playListItems;

    public List<PlayListItem> getPlayListItems() {
        return playListItems;
    }

    public void setPlayListItems(List<PlayListItem> playListItems) {
        this.playListItems = playListItems;
    }

    @Override
    public String toString() {
        return "Result{\n" +
                "playListItems=" + playListItems +
                "\n}";
    }
}
