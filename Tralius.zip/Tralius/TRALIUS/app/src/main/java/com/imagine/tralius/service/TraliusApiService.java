package com.imagine.tralius.service;

import com.imagine.tralius.service.data.company.CompanyResult;
import com.imagine.tralius.service.data.playlist.PlayListResult;
import com.imagine.tralius.service.data.serial.SerialResult;
import com.imagine.tralius.service.data.transition.TransitionResult;
import com.imagine.tralius.service.data.update.UpdateResult;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * Created by Elvis on 2/8/2018.
 */

public interface TraliusApiService {

    String API_URL = "http://app.tralius.com";

    @GET("/api/device/GetNewSerial")
    Call<SerialResult> getNewSerial();

    @GET("/api/transitioneffects")
    Call<TransitionResult> getTransitionEfects();

    @GET("/api/PlayLists/GetData/{serial}")
    Call<PlayListResult> getData(@Path("serial") String serial);

    @GET("/api/device/GetSettings/{serial}")
    Call<CompanyResult> getSettings(@Path("serial") String serial);

    @GET("/api/device/GetSoftwareUpdates/{serial}")
    Call<UpdateResult> getUpdates(@Path("serial") String serial);

}
