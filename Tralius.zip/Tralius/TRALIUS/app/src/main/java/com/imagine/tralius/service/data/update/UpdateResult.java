
package com.imagine.tralius.service.data.update;

import com.google.gson.annotations.SerializedName;
import com.imagine.tralius.service.data.Error;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class UpdateResult {

    @SerializedName("Error")
    private Error error;
    @SerializedName("Result")
    private com.imagine.tralius.service.data.update.Result result;
    @SerializedName("StatusCode")
    private Long statusCode;

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public Long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Long statusCode) {
        this.statusCode = statusCode;
    }
}
