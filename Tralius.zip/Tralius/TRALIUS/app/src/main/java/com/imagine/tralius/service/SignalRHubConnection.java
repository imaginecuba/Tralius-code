package com.imagine.tralius.service;


/* Class to create a SignalR Connection */

import android.content.Context;
import android.util.Log;

/*import com.google.gson.Gson;

import microsoft.aspnet.signalr.client.Action;
import microsoft.aspnet.signalr.client.ErrorCallback;
import microsoft.aspnet.signalr.client.LogLevel;
import microsoft.aspnet.signalr.client.Logger;
import microsoft.aspnet.signalr.client.Platform;
import microsoft.aspnet.signalr.client.SignalRFuture;
import microsoft.aspnet.signalr.client.http.android.AndroidPlatformComponent;
import microsoft.aspnet.signalr.client.hubs.HubConnection;
import microsoft.aspnet.signalr.client.hubs.HubProxy;
import microsoft.aspnet.signalr.client.hubs.SubscriptionHandler1;
import microsoft.aspnet.signalr.client.transport.ClientTransport;
import microsoft.aspnet.signalr.client.transport.LongPollingTransport;*/

public class SignalRHubConnection {

    private static final String TAG = "TRALIUS-SignalR";
//    public static HubConnection mHubConnection;
//    public static HubProxy mHubProxy;
    private static Context context;
    public static String mConnectionID;

    public SignalRHubConnection(Context context) {
        this.context = context;
    }


    /*public static void startSignalR() {
        Platform.loadPlatformComponent(new AndroidPlatformComponent());
        mHubConnection = new HubConnection("http://app.tralius.com/signalr/hubs", "", false,
                                           new Logger() {
                                               @Override
                                               public void log(String s, LogLevel logLevel) {
                                                   Log.wtf(TAG, s);
                                               }
                                           });
        mHubProxy = mHubConnection.createHubProxy("traliusHub");
        ClientTransport clientTransport = new LongPollingTransport(
                mHubConnection.getLogger());
        SignalRFuture<Void> signalRFuture = mHubConnection.start(clientTransport);

        signalRFuture.done(new Action<Void>() {
            @Override
            public void run(Void aVoid) throws Exception {
                //Hub connected
                //set connection id
                mConnectionID = mHubConnection.getConnectionId();
                mHubProxy.invoke("connect", "F7PKEL8HPL6DNZ4L", mConnectionID);
                Log.wtf(TAG, "returned: connected");

                mHubProxy.invoke("notify");




            }
        })
                .onError(new ErrorCallback() {
                    @Override
                    public void onError(Throwable throwable) {
                        //connection error
                        Log.wtf(TAG, "returned: error");
                    }
                })
                .onCancelled(new Runnable() {
                    @Override
                    public void run() {
                        //connection canceled
                        Log.wtf(TAG, "returned: canceled");
                    }
                });

        //subscribe to method
        mHubProxy.on("connect",
                     new SubscriptionHandler1<Object>() {
                         @Override
                         public void run(final Object msg) {
                             Log.wtf(TAG, "run() returned: " + new Gson().toJson(msg));
                         }
                     }
                , Object.class);
        mHubProxy.on("notify",
                     new SubscriptionHandler1<Object>() {
                         @Override
                         public void run(final Object msg) {
                             Log.wtf(TAG, "run() returned: " + new Gson().toJson(msg));
                         }
                     }
                , Object.class);


    }*/


}

