
package com.imagine.tralius.service.data.transition;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class TransitionResult {

    @SerializedName("Error")
    private com.imagine.tralius.service.data.Error error;
    @SerializedName("Result")
    private com.imagine.tralius.service.data.transition.Result result;
    @SerializedName("StatusCode")
    private Long statusCode;

    public com.imagine.tralius.service.data.Error getError() {
        return error;
    }

    public void setError(com.imagine.tralius.service.data.Error error) {
        this.error = error;
    }

    public com.imagine.tralius.service.data.transition.Result getResult() {
        return result;
    }

    public void setResult(com.imagine.tralius.service.data.transition.Result result) {
        this.result = result;
    }

    public Long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Long statusCode) {
        this.statusCode = statusCode;
    }

    @Override
    public String toString() {
        return "TransitionResult{" +
                "error=" + error +
                ", result=" + result +
                ", statusCode=" + statusCode +
                '}';
    }
}
