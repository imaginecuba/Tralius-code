package com.imagine.tralius.kiosko;

import android.content.Context;
import android.os.PowerManager;
import android.view.KeyEvent;

import org.polaric.colorful.ColorfulActivity;

/**
 * Created by Elvis on 2/18/2018.
 */

public class KioskoModeActivity extends ColorfulActivity {
    private PowerManager.WakeLock wakeLock;
    private OnScreenOffReceiver onScreenOffReceiver;
    protected boolean isLockedBackButton = true;

    /*private void registerKioskModeScreenOffReceiver() {
        // register screen off receiver
        final IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        onScreenOffReceiver = new OnScreenOffReceiver();
        registerReceiver(onScreenOffReceiver, filter);
    }*/

    public PowerManager.WakeLock getWakeLock() {
        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "wakeup");
        }
        return wakeLock;
    }

/*    private void startKioskService() { // ... and this method
        startService(new Intent(this, KioskService.class));
    }*/

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return !isLockedBackButton && keyCode == KeyEvent.KEYCODE_BACK
               ? super.onKeyDown(keyCode, event)
               : true;
    }


}
