
package com.imagine.tralius.service.data.company;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Result {

    @SerializedName("Item")
    private com.imagine.tralius.service.data.company.Item item;

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "Result{" +
                "item=" + item +
                '}';
    }
}
