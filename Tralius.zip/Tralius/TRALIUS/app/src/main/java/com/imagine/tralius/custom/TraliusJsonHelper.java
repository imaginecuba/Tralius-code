package com.imagine.tralius.custom;

import org.json.JSONException;
import org.json.JSONObject;

public class TraliusJsonHelper {

    public static JSONObject ToJSONObject(String text) {
        JSONObject json;
        if (text == null) {
            return null;
        }
        try {
            json = new JSONObject(text);
        }
        catch (JSONException e) {
            json = null;
        }
        return json;
    }
}
