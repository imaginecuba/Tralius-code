
package com.imagine.tralius.service.data.serial;

import javax.annotation.Generated;

import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class SerialResult {

    @SerializedName("Error")
    private com.imagine.tralius.service.data.Error error;
    @SerializedName("Result")
    private Result result;
    @SerializedName("StatusCode")
    private Long statusCode;

    public com.imagine.tralius.service.data.Error getError() {
        return error;
    }

    public void setError(com.imagine.tralius.service.data.Error error) {
        this.error = error;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public Long getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Long statusCode) {
        this.statusCode = statusCode;
    }

    @Override
    public String toString() {
        return "SerialResult{" +
                "error=" + error +
                ", result=" + result +
                ", statusCode=" + statusCode +
                '}';
    }
}
