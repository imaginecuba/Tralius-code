package org.polaric.colorful;

class Util {
    static final String LOG_TAG="Colorful";
    static final String PREFERENCE_KEY="COLORFUL_PREF_KEY";
}
