package org.polaric.colorful;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.v7.preference.PreferenceManager;
import android.util.Log;

public class Colorful {
    private static ThemeDelegate delegate;
    private static ThemeColor primaryColor = Defaults.primaryColor;
    private static ThemeColor accentColor = Defaults.accentColor;
    private static boolean isTranslucent = Defaults.trans;
    private static boolean isDark = Defaults.darkTheme;
    private static String themeString;

    private Colorful() {
        // prevent initialization
    }

    public static void init(Context context) {
        Log.d(Util.LOG_TAG, "Attatching to " + context.getPackageName());
        themeString = PreferenceManager.getDefaultSharedPreferences(context).getString(
                Util.PREFERENCE_KEY, null);
        if (themeString == null) {
            primaryColor = Defaults.primaryColor;
            accentColor = Defaults.accentColor;
            isTranslucent = Defaults.trans;
            isDark = Defaults.darkTheme;
            themeString = generateThemeString();
        }
        else {
            initValues();
        }
        delegate = new ThemeDelegate(context, primaryColor, accentColor, isTranslucent, isDark);
    }

    public static void applyTheme(@NonNull Activity activity) {
        applyTheme(activity, true);
    }

    public static void applyTheme(@NonNull Activity activity, boolean overrideBase) {
        if (overrideBase) {
            activity.setTheme(getThemeDelegate().getStyleResBase());
        }
        activity.getTheme().applyStyle(getThemeDelegate().getStyleResPrimary(), true);
        activity.getTheme().applyStyle(getThemeDelegate().getStyleResAccent(), true);
    }

    private static void writeValues(Context context) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString(Util.PREFERENCE_KEY,
                                                                                generateThemeString()).apply();
    }

    private static void initValues() {
        String[] colors = themeString.split(":");
        isDark = Boolean.parseBoolean(colors[0]);
        isTranslucent = Boolean.parseBoolean(colors[1]);
        primaryColor = Colorful.ThemeColor.values()[Integer.parseInt(colors[2])];
        accentColor = Colorful.ThemeColor.values()[Integer.parseInt(colors[3])];
    }

    private static String generateThemeString() {
        return isDark + ":" + isTranslucent + ":" + primaryColor.ordinal() + ":" + accentColor
                .ordinal();
    }

    public static ThemeDelegate getThemeDelegate() {
        if (delegate == null) {
            Log.e(Util.LOG_TAG,
                  "getThemeDelegate() called before init(Context). Call Colorful.init(Context) in" +
                          " your application class");
        }
        return delegate;
    }

    public static String getThemeString() {
        return themeString;
    }

    public enum ThemeColor {
        /*RED(Color.RED, Color.RED),
        DEEP_PURPLE(Color.BLUE, Color.BLUE),
        YELLOW(Color.YELLOW, Color.YELLOW),
        CYAN(Color.CYAN, Color.CYAN);*/

        /*PINK(R.color.md_pink_500, R.color.md_pink_700),
        PURPLE(R.color.md_purple_500, R.color.md_purple_700),
        INDIGO(R.color.md_indigo_500, R.color.md_indigo_700),
        BLUE(R.color.md_blue_500, R.color.md_blue_700),
        LIGHT_BLUE(R.color.md_light_blue_500, R.color.md_light_blue_700),
        CYAN(R.color.md_cyan_500, R.color.md_cyan_700),
        TEAL(R.color.md_teal_500, R.color.md_teal_700),
        GREEN(R.color.md_green_500, R.color.md_green_700),
        LIGHT_GREEN(R.color.md_light_green_500, R.color.md_light_green_700),
        LIME(R.color.md_lime_500, R.color.md_lime_700),
        YELLOW(R.color.md_yellow_500, R.color.md_yellow_700),
        AMBER(R.color.md_amber_500, R.color.md_amber_700),
        ORANGE(R.color.md_orange_500, R.color.md_orange_700),
        DEEP_ORANGE(R.color.md_deep_orange_500, R.color.md_deep_orange_700),
        BROWN(R.color.md_brown_500, R.color.md_brown_700),
        GREY(R.color.md_grey_500, R.color.md_grey_700),
        BLUE_GREY(R.color.md_blue_grey_500, R.color.md_blue_grey_700),
        WHITE(R.color.md_white_1000, R.color.md_white_1000),
        BLACK(R.color.md_black_1000, R.color.md_black_1000);*/

        /*@ColorInt
        private int color;
        @ColorInt
        private int darkColor;

        ThemeColor(@ColorInt int color, @ColorInt int darkColor) {
            this.color = color;
            this.darkColor = darkColor;
        }

        public @ColorInt
        int getColor() {
            return color;
        }

        public @ColorInt
        int getDarkColor() {
            return darkColor;
        }*/
        RED_50(R.color.md_red_50, R.color.md_red_100),
        RED_100(R.color.md_red_100, R.color.md_red_300),
        RED_200(R.color.md_red_100, R.color.md_red_400),
        RED_300(R.color.md_red_300, R.color.md_red_500),
        RED_400(R.color.md_red_400, R.color.md_red_600),
        RED_500(R.color.md_red_500, R.color.md_red_700),
        RED_600(R.color.md_red_600, R.color.md_red_800),
        RED_700(R.color.md_red_700, R.color.md_red_900),
        RED_800(R.color.md_red_800, R.color.md_red_A100),
        RED_900(R.color.md_red_800, R.color.md_red_A200),
        RED_A100(R.color.md_red_A100, R.color.md_red_A400),
        RED_A200(R.color.md_red_A200, R.color.md_red_A700),

        PINK_50(R.color.md_pink_50, R.color.md_pink_100),
        PINK_100(R.color.md_pink_100, R.color.md_pink_300),
        PINK_200(R.color.md_pink_200, R.color.md_pink_400),
        PINK_300(R.color.md_pink_300, R.color.md_pink_500),
        PINK_400(R.color.md_pink_400, R.color.md_pink_600),
        PINK_500(R.color.md_pink_500, R.color.md_pink_700),
        PINK_600(R.color.md_pink_600, R.color.md_pink_800),
        PINK_700(R.color.md_pink_700, R.color.md_pink_900),
        PINK_800(R.color.md_pink_800, R.color.md_pink_A100),
        PINK_900(R.color.md_pink_900, R.color.md_pink_A200),
        PINK_A100(R.color.md_pink_A100, R.color.md_pink_A400),
        PINK_A200(R.color.md_pink_A200, R.color.md_pink_A700),



        PURPLE_50(R.color.md_purple_50, R.color.md_purple_100),
        PURPLE_100(R.color.md_purple_100, R.color.md_purple_300),
        PURPLE_200(R.color.md_purple_200, R.color.md_purple_400),
        PURPLE_300(R.color.md_purple_300, R.color.md_purple_500),
        PURPLE_400(R.color.md_purple_400, R.color.md_purple_600),
        PURPLE_500(R.color.md_purple_500, R.color.md_purple_700),
        PURPLE_600(R.color.md_purple_600, R.color.md_purple_800),
        PURPLE_700(R.color.md_purple_700, R.color.md_purple_900),
        PURPLE_800(R.color.md_purple_800, R.color.md_purple_A100),
        PURPLE_900(R.color.md_purple_900, R.color.md_purple_A200),
        PURPLE_A100(R.color.md_purple_A100, R.color.md_purple_A400),
        PURPLE_A200(R.color.md_purple_A200, R.color.md_purple_A700),


        DEEP_PURPLE_50(R.color.md_deep_purple_50, R.color.md_deep_purple_100),
        DEEP_PURPLE_100(R.color.md_deep_purple_100, R.color.md_deep_purple_200),
        DEEP_PURPLE_200(R.color.md_deep_purple_200, R.color.md_deep_purple_300),
        DEEP_PURPLE_300(R.color.md_deep_purple_300, R.color.md_deep_purple_500),
        DEEP_PURPLE_400(R.color.md_deep_purple_400, R.color.md_deep_purple_600),
        DEEP_PURPLE_500(R.color.md_deep_purple_500, R.color.md_deep_purple_700),
        DEEP_PURPLE_600(R.color.md_deep_purple_600, R.color.md_deep_purple_800),
        DEEP_PURPLE_700(R.color.md_deep_purple_700, R.color.md_deep_purple_900),
        DEEP_PURPLE_800(R.color.md_deep_purple_800, R.color.md_deep_purple_A100),
        DEEP_PURPLE_900(R.color.md_deep_purple_900, R.color.md_deep_purple_A200),
        DEEP_PURPLE_A100(R.color.md_deep_purple_A100, R.color.md_deep_purple_A400),
        DEEP_PURPLE_A200(R.color.md_deep_purple_A200, R.color.md_deep_purple_A700),


        INDIGO_50(R.color.md_indigo_50, R.color.md_indigo_100),
        INDIGO_100(R.color.md_indigo_100, R.color.md_indigo_200),
        INDIGO_200(R.color.md_indigo_200, R.color.md_indigo_400),
        INDIGO_300(R.color.md_indigo_300, R.color.md_indigo_500),
        INDIGO_400(R.color.md_indigo_400, R.color.md_indigo_600),
        INDIGO_500(R.color.md_indigo_500, R.color.md_indigo_700),
        INDIGO_600(R.color.md_indigo_600, R.color.md_indigo_800),
        INDIGO_700(R.color.md_indigo_700, R.color.md_indigo_900),
        INDIGO_800(R.color.md_indigo_800, R.color.md_indigo_A100),
        INDIGO_900(R.color.md_indigo_900, R.color.md_indigo_A200),
        INDIGO_A100(R.color.md_indigo_A100, R.color.md_indigo_A400),
        INDIGO_A200(R.color.md_indigo_A200, R.color.md_indigo_A700),


        BLUE_50(R.color.md_blue_50, R.color.md_blue_100),
        BLUE_100(R.color.md_blue_100, R.color.md_blue_200),
        BLUE_200(R.color.md_blue_200, R.color.md_blue_400),
        BLUE_300(R.color.md_blue_300, R.color.md_blue_500),
        BLUE_400(R.color.md_blue_400, R.color.md_blue_600),
        BLUE_500(R.color.md_blue_500, R.color.md_blue_700),
        BLUE_600(R.color.md_blue_600, R.color.md_blue_800),
        BLUE_700(R.color.md_blue_700, R.color.md_blue_900),
        BLUE_800(R.color.md_blue_800, R.color.md_blue_A100),
        BLUE_900(R.color.md_blue_900, R.color.md_blue_A200),
        BLUE_A100(R.color.md_blue_A100, R.color.md_blue_A400),
        BLUE_A200(R.color.md_blue_A200, R.color.md_blue_A700),


        LIGHT_BLUE_50(R.color.md_light_blue_50, R.color.md_light_blue_100),
        LIGHT_BLUE_100(R.color.md_light_blue_100, R.color.md_light_blue_200),
        LIGHT_BLUE_200(R.color.md_light_blue_200, R.color.md_light_blue_400),
        LIGHT_BLUE_300(R.color.md_light_blue_300, R.color.md_light_blue_500),
        LIGHT_BLUE_400(R.color.md_light_blue_400, R.color.md_light_blue_600),
        LIGHT_BLUE_500(R.color.md_light_blue_500, R.color.md_light_blue_700),
        LIGHT_BLUE_600(R.color.md_light_blue_600, R.color.md_light_blue_800),
        LIGHT_BLUE_700(R.color.md_light_blue_700, R.color.md_light_blue_900),
        LIGHT_BLUE_800(R.color.md_light_blue_800, R.color.md_light_blue_A100),
        LIGHT_BLUE_900(R.color.md_light_blue_900, R.color.md_light_blue_A200),
        LIGHT_BLUE_A100(R.color.md_light_blue_A100, R.color.md_light_blue_A400),
        LIGHT_BLUE_A200(R.color.md_light_blue_A200, R.color.md_light_blue_A700),


        CYAN_50(R.color.md_cyan_50, R.color.md_cyan_100),
        CYAN_100(R.color.md_cyan_100, R.color.md_cyan_200),
        CYAN_200(R.color.md_cyan_200, R.color.md_cyan_400),
        CYAN_300(R.color.md_cyan_300, R.color.md_cyan_500),
        CYAN_400(R.color.md_cyan_400, R.color.md_cyan_600),
        CYAN_500(R.color.md_cyan_500, R.color.md_cyan_700),
        CYAN_600(R.color.md_cyan_600, R.color.md_cyan_800),
        CYAN_700(R.color.md_cyan_700, R.color.md_cyan_900),
        CYAN_800(R.color.md_cyan_800, R.color.md_cyan_A100),
        CYAN_900(R.color.md_cyan_900, R.color.md_cyan_A200),
        CYAN_A100(R.color.md_cyan_A100, R.color.md_cyan_A400),
        CYAN_A200(R.color.md_cyan_A200, R.color.md_cyan_A700),

        TEAL_50(R.color.md_teal_50, R.color.md_teal_100),
        TEAL_100(R.color.md_teal_100, R.color.md_teal_200),
        TEAL_200(R.color.md_teal_200, R.color.md_teal_400),
        TEAL_300(R.color.md_teal_300, R.color.md_teal_500),
        TEAL_400(R.color.md_teal_400, R.color.md_teal_600),
        TEAL_500(R.color.md_teal_500, R.color.md_teal_700),
        TEAL_600(R.color.md_teal_600, R.color.md_teal_800),
        TEAL_700(R.color.md_teal_700, R.color.md_teal_900),
        TEAL_800(R.color.md_teal_800, R.color.md_teal_A100),
        TEAL_900(R.color.md_teal_900, R.color.md_teal_A200),
        TEAL_A100(R.color.md_teal_A100, R.color.md_teal_A400),
        TEAL_A200(R.color.md_teal_A200, R.color.md_teal_A700),

        GREEN_50(R.color.md_green_50, R.color.md_green_100),
        GREEN_100(R.color.md_green_100, R.color.md_green_200),
        GREEN_200(R.color.md_green_200, R.color.md_green_400),
        GREEN_300(R.color.md_green_300, R.color.md_green_500),
        GREEN_400(R.color.md_green_400, R.color.md_green_600),
        GREEN_500(R.color.md_green_500, R.color.md_green_700),
        GREEN_600(R.color.md_green_600, R.color.md_green_800),
        GREEN_700(R.color.md_green_700, R.color.md_green_900),
        GREEN_800(R.color.md_green_800, R.color.md_green_A100),
        GREEN_900(R.color.md_green_900, R.color.md_green_A200),
        GREEN_A100(R.color.md_green_A100, R.color.md_green_A400),
        GREEN_A200(R.color.md_green_A200, R.color.md_green_A700),

        LIGHT_GREEN_50(R.color.md_light_green_50, R.color.md_light_green_100),
        LIGHT_GREEN_100(R.color.md_light_green_100, R.color.md_light_green_200),
        LIGHT_GREEN_200(R.color.md_light_green_200, R.color.md_light_green_400),
        LIGHT_GREEN_300(R.color.md_light_green_300, R.color.md_light_green_500),
        LIGHT_GREEN_400(R.color.md_light_green_400, R.color.md_light_green_600),
        LIGHT_GREEN_500(R.color.md_light_green_500, R.color.md_light_green_700),
        LIGHT_GREEN_600(R.color.md_light_green_600, R.color.md_light_green_800),
        LIGHT_GREEN_700(R.color.md_light_green_700, R.color.md_light_green_900),
        LIGHT_GREEN_800(R.color.md_light_green_800, R.color.md_light_green_A100),
        LIGHT_GREEN_900(R.color.md_light_green_900, R.color.md_light_green_A200),
        LIGHT_GREEN_A100(R.color.md_light_green_A100, R.color.md_light_green_A400),
        LIGHT_GREEN_A200(R.color.md_light_green_A200, R.color.md_light_green_A700),

        LIME_50(R.color.md_lime_50, R.color.md_lime_100),
        LIME_100(R.color.md_lime_100, R.color.md_lime_200),
        LIME_200(R.color.md_lime_200, R.color.md_lime_400),
        LIME_300(R.color.md_lime_300, R.color.md_lime_500),
        LIME_400(R.color.md_lime_400, R.color.md_lime_600),
        LIME_500(R.color.md_lime_500, R.color.md_lime_700),
        LIME_600(R.color.md_lime_600, R.color.md_lime_800),
        LIME_700(R.color.md_lime_700, R.color.md_lime_900),
        LIME_800(R.color.md_lime_800, R.color.md_lime_A100),
        LIME_900(R.color.md_lime_900, R.color.md_lime_A200),
        LIME_A100(R.color.md_lime_A100, R.color.md_lime_A400),
        LIME_A200(R.color.md_lime_A200, R.color.md_lime_A700),

        YELLOW_50(R.color.md_yellow_50, R.color.md_yellow_100),
        YELLOW_100(R.color.md_yellow_100, R.color.md_yellow_200),
        YELLOW_200(R.color.md_yellow_200, R.color.md_yellow_400),
        YELLOW_300(R.color.md_yellow_300, R.color.md_yellow_500),
        YELLOW_400(R.color.md_yellow_400, R.color.md_yellow_600),
        YELLOW_500(R.color.md_yellow_500, R.color.md_yellow_700),
        YELLOW_600(R.color.md_yellow_600, R.color.md_yellow_800),
        YELLOW_700(R.color.md_yellow_700, R.color.md_yellow_900),
        YELLOW_800(R.color.md_yellow_800, R.color.md_yellow_A100),
        YELLOW_900(R.color.md_yellow_900, R.color.md_yellow_A200),
        YELLOW_A100(R.color.md_yellow_A100, R.color.md_yellow_A400),
        YELLOW_A200(R.color.md_yellow_A200, R.color.md_yellow_A700),

        AMBER_50(R.color.md_amber_50, R.color.md_amber_100),
        AMBER_100(R.color.md_amber_100, R.color.md_amber_100),
        AMBER_200(R.color.md_amber_200, R.color.md_amber_200),
        AMBER_300(R.color.md_amber_300, R.color.md_amber_400),
        AMBER_400(R.color.md_amber_400, R.color.md_amber_500),
        AMBER_500(R.color.md_amber_500, R.color.md_amber_600),
        AMBER_600(R.color.md_amber_600, R.color.md_amber_700),
        AMBER_700(R.color.md_amber_700, R.color.md_amber_800),
        AMBER_800(R.color.md_amber_800, R.color.md_amber_A100),
        AMBER_900(R.color.md_amber_900, R.color.md_amber_A200),
        AMBER_A100(R.color.md_amber_A100, R.color.md_amber_A400),
        AMBER_A200(R.color.md_amber_A200, R.color.md_amber_A700),

        ORANGE_50(R.color.md_orange_50, R.color.md_orange_100),
        ORANGE_100(R.color.md_orange_100, R.color.md_orange_200),
        ORANGE_200(R.color.md_orange_200, R.color.md_orange_400),
        ORANGE_300(R.color.md_orange_300, R.color.md_orange_500),
        ORANGE_400(R.color.md_orange_400, R.color.md_orange_600),
        ORANGE_500(R.color.md_orange_500, R.color.md_orange_700),
        ORANGE_600(R.color.md_orange_600, R.color.md_orange_800),
        ORANGE_700(R.color.md_orange_700, R.color.md_orange_900),
        ORANGE_800(R.color.md_orange_800, R.color.md_orange_A100),
        ORANGE_900(R.color.md_orange_900, R.color.md_orange_A200),
        ORANGE_A100(R.color.md_orange_A100, R.color.md_orange_A400),
        ORANGE_A200(R.color.md_orange_A200, R.color.md_orange_A700),

        DEEP_ORANGE_50(R.color.md_deep_orange_50, R.color.md_deep_orange_100),
        DEEP_ORANGE_100(R.color.md_deep_orange_100, R.color.md_deep_orange_200),
        DEEP_ORANGE_200(R.color.md_deep_orange_200, R.color.md_deep_orange_400),
        DEEP_ORANGE_300(R.color.md_deep_orange_300, R.color.md_deep_orange_500),
        DEEP_ORANGE_400(R.color.md_deep_orange_400, R.color.md_deep_orange_600),
        DEEP_ORANGE_500(R.color.md_deep_orange_500, R.color.md_deep_orange_700),
        DEEP_ORANGE_600(R.color.md_deep_orange_600, R.color.md_deep_orange_800),
        DEEP_ORANGE_700(R.color.md_deep_orange_700, R.color.md_deep_orange_900),
        DEEP_ORANGE_800(R.color.md_deep_orange_800, R.color.md_deep_orange_A100),
        DEEP_ORANGE_900(R.color.md_deep_orange_900, R.color.md_deep_orange_A200),
        DEEP_ORANGE_A100(R.color.md_deep_orange_A100, R.color.md_deep_orange_A400),
        DEEP_ORANGE_A200(R.color.md_deep_orange_A200, R.color.md_deep_orange_A700),

        BROWN_50(R.color.md_brown_50, R.color.md_brown_100),
        BROWN_100(R.color.md_brown_100, R.color.md_brown_200),
        BROWN_200(R.color.md_brown_200, R.color.md_brown_400),
        BROWN_300(R.color.md_brown_300, R.color.md_brown_500),
        BROWN_400(R.color.md_brown_400, R.color.md_brown_600),
        BROWN_500(R.color.md_brown_500, R.color.md_brown_700),
        BROWN_600(R.color.md_brown_600, R.color.md_brown_800),
        BROWN_700(R.color.md_brown_700, R.color.md_brown_900),

        GREY_50(R.color.md_grey_50, R.color.md_grey_100),
        GREY_100(R.color.md_grey_100, R.color.md_grey_200),
        GREY_200(R.color.md_grey_200, R.color.md_grey_400),
        GREY_300(R.color.md_grey_300, R.color.md_grey_500),
        GREY_400(R.color.md_grey_400, R.color.md_grey_600),
        GREY_500(R.color.md_grey_500, R.color.md_grey_700),
        GREY_600(R.color.md_grey_600, R.color.md_grey_800),
        GREY_700(R.color.md_grey_700, R.color.md_grey_900),


        BLUE_GREY_50(R.color.md_blue_grey_50, R.color.md_blue_grey_100),
        BLUE_GREY_100(R.color.md_blue_grey_100, R.color.md_blue_grey_200),
        BLUE_GREY_200(R.color.md_blue_grey_100, R.color.md_blue_grey_400),
        BLUE_GREY_300(R.color.md_blue_grey_100, R.color.md_blue_grey_500),
        BLUE_GREY_400(R.color.md_blue_grey_100, R.color.md_blue_grey_600),
        BLUE_GREY_500(R.color.md_blue_grey_100, R.color.md_blue_grey_700),
        BLUE_GREY_600(R.color.md_blue_grey_100, R.color.md_blue_grey_800),
        BLUE_GREY_700(R.color.md_blue_grey_100, R.color.md_blue_grey_900),


        WHITE_1000(R.color.md_white_1000, R.color.md_white_1000),
        BLACK_1000(R.color.md_black_1000, R.color.md_black_1000);


        @ColorRes
        private int colorRes;
        @ColorRes
        private int darkColorRes;

        ThemeColor(@ColorRes int colorRes, @ColorRes int darkColorRes) {
            this.colorRes = colorRes;
            this.darkColorRes = darkColorRes;
        }

        public @ColorRes
        int getColorRes() {
            return colorRes;
        }

        public @ColorRes
        int getDarkColorRes() {
            return darkColorRes;
        }

    }

    public static Config config(Context context) {
        return new Config(context);
    }

    public static Defaults defaults() {
        return new Defaults();
    }

    public static class Defaults {

        private static ThemeColor primaryColor = ThemeColor.DEEP_PURPLE_500;
        private static ThemeColor accentColor = ThemeColor.RED_500;
        private static boolean trans = false;
        private static boolean darkTheme = false;

        public Defaults primaryColor(ThemeColor primary) {
            primaryColor = primary;
            return this;
        }

        public Defaults accentColor(ThemeColor accent) {
            accentColor = accent;
            return this;
        }

        public Defaults translucent(boolean translucent) {
            trans = translucent;
            return this;
        }

        public Defaults dark(boolean dark) {
            darkTheme = dark;
            return this;
        }

        //////////////////////////////////////////////////////

        public static ThemeColor getPrimaryColor() {
            return primaryColor;
        }

        public static ThemeColor getAccentColor() {
            return accentColor;
        }

        public static boolean isDarkTheme() {
            return isDark;
        }
    }

    public static class Config {
        private Context context;

        private Config(Context context) {
            this.context = context;
        }

        public Config primaryColor(ThemeColor primary) {
            primaryColor = primary;
            return this;
        }

        public Config accentColor(ThemeColor accent) {
            accentColor = accent;
            return this;
        }

        public Config translucent(boolean translucent) {
            isTranslucent = translucent;
            return this;
        }

        public Config dark(boolean dark) {
            isDark = dark;
            return this;
        }

        public void apply() {
            writeValues(context);
            themeString = generateThemeString();
            delegate = new ThemeDelegate(context, primaryColor, accentColor, isTranslucent, isDark);
        }
    }

}
